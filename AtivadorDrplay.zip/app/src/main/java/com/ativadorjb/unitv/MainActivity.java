
package com.ativadorjb.unitv;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.*;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView status;
    Uri arquivo;
    File configLocal;
    final int PEDIR_PERMISSAO = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Ativador WillbootJB");
        }

        getWindow().setBackgroundDrawableResource(R.drawable.fundo_app);

        LinearLayout externo = new LinearLayout(this);
        externo.setOrientation(LinearLayout.VERTICAL);
        externo.setGravity(Gravity.CENTER_HORIZONTAL);
        externo.setPadding(30, 30, 30, 30);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);

        int larguraMax = (int) (650 * getResources().getDisplayMetrics().density);
        int larguraTela = getResources().getDisplayMetrics().widthPixels;
        int larguraFinal = Math.min(larguraTela - 60, larguraMax);

        LinearLayout.LayoutParams paramsL = new LinearLayout.LayoutParams(
                larguraFinal,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        l.setLayoutParams(paramsL);

        l.addView(btnComCirculo("LIMPEZA", v -> onDeleteAll()));
        l.addView(btnComCirculo("SELECIONAR CONFIG", v -> selecionarConfig()));
        l.addView(btnComCirculo("ATIVAÇÃO", v -> onActivate()));
        l.addView(btnComCirculo("INSTALAR APPS", v -> mostrarMenuInstalacao()));
        l.addView(btnComCirculo("SAIR DO APP", v -> finishAffinity()));

        TextView instrucoes = new TextView(this);

        instrucoes.setText(
                "📋 PASSO A PASSO:\n\n" +
                "1 - Faça a limpeza.\n" +
                "2 - Desinstalar o UniTV Free (caso tenha instalado).\n" +
                "3 - Clique em SELECIONAR CONFIG e escolha o arquivo .config.\n" +
                "4 - Clique em ATIVAÇÃO.\n" +
                "5 - Faça a Instalação do UniTV Free.\n\n" +
                "Obs: caso dê erro no seu UniTV Free\n" +
                "• Desinstale o UniTV Free.\n" +
                "• Faça a limpeza.\n" +
                "• Selecione a Config.\n" +
                "• Faça a ativação.\n" +
                "• Instalar o UniTV Free 4.21.0, abra e vá até a parte que pede para atualizar.\n" +
                "• Agora baixe e instale o UniTV Free 5.9.0 e seja Feliz."
        );

        instrucoes.setTextColor(0xFFFFFFFF);
        instrucoes.setPadding(25, 25, 25, 25);
        instrucoes.setTypeface(null, Typeface.BOLD);
        instrucoes.setTextSize(13);
        instrucoes.setLineSpacing(6, 1.15f);

        android.graphics.drawable.GradientDrawable gdCard =
                new android.graphics.drawable.GradientDrawable();

        gdCard.setColor(0x55555555);
        gdCard.setCornerRadius(15);
        gdCard.setStroke(1, 0xFFAAAAAA);

        instrucoes.setBackground(gdCard);
        l.addView(instrucoes);

        status = new TextView(this);
        status.setText("Status: Aguardando ação");
        status.setPadding(15, 15, 15, 15);
        status.setTextColor(0xFF00FF00);
        status.setTextSize(14);
        status.setTypeface(null, Typeface.BOLD);
        status.setGravity(Gravity.CENTER);

        android.graphics.drawable.GradientDrawable gdLog =
                new android.graphics.drawable.GradientDrawable();

        gdLog.setColor(0x44000000);
        gdLog.setCornerRadius(12);

        status.setBackground(gdLog);
        l.addView(status);

        externo.addView(l);

        ScrollView sv = new ScrollView(this);
        sv.addView(externo);

        setContentView(sv);

        pedirPermissao();
    }

    // ===== SELECIONAR CONFIG =====

    void selecionarConfig() {

        File pastaDownload = new File("/storage/emulated/0/Download");

        if (!pastaDownload.exists()) {
            pastaDownload = new File("/storage/emulated/0/Downloads");
        }

        if (!pastaDownload.exists()) {
            pastaDownload = new File("/storage/emulated/0");
        }

        abrirPastaTV(pastaDownload);
    }

    void abrirPastaTV(File pasta) {

        File[] arquivos = pasta.listFiles();

        if (arquivos == null) arquivos = new File[0];

        java.util.Arrays.sort(arquivos, (a, b) -> {
            if (a.isDirectory() && !b.isDirectory()) return -1;
            if (!a.isDirectory() && b.isDirectory()) return 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 30, 40, 30);
        layout.setBackgroundColor(0xFF444444);

        TextView titulo = new TextView(this);
        titulo.setText("Pasta: " + pasta.getAbsolutePath());
        titulo.setTextColor(0xFFFFFFFF);
        titulo.setTypeface(null, Typeface.BOLD);
        titulo.setPadding(0, 0, 0, 20);

        layout.addView(titulo);

        ListView lista = new ListView(this);

        ArrayList<String> nomes = new ArrayList<>();
        ArrayList<File> listaFiles = new ArrayList<>();

        if (pasta.getParentFile() != null) {
            nomes.add("⬆️ ... VOLTAR");
            listaFiles.add(pasta.getParentFile());
        }

        for (File f : arquivos) {

            if (f.isDirectory()) {
                nomes.add("📁 " + f.getName());
                listaFiles.add(f);

            } else {

                if (f.getName().endsWith(".config") ||
                        f.getName().equals(".config") ||
                        !f.getName().contains(".")) {

                    nomes.add("📄 " + f.getName());
                    listaFiles.add(f);
                }
            }
        }

        if (nomes.size() == 0 ||
                (nomes.size() == 1 && nomes.get(0).contains("VOLTAR"))) {

            nomes.add("Nenhum arquivo .config aqui");
            listaFiles.add(pasta);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                nomes
        ) {
            @Override
            public View getView(int position, View convertView,
                                android.view.ViewGroup parent) {

                TextView tv = (TextView) super.getView(
                        position, convertView, parent
                );

                tv.setTextColor(0xFFFFFFFF);
                tv.setTextSize(16);
                tv.setPadding(20, 25, 20, 25);

                return tv;
            }
        };

        lista.setAdapter(adapter);
        layout.addView(lista);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(layout)
                .setNegativeButton("FECHAR", null)
                .create();

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(
                    android.R.color.transparent
            );
        }

        lista.setOnItemClickListener((parent, view, pos, id) -> {

            if (nomes.get(pos).equals("Nenhum arquivo .config aqui")) {
                return;
            }

            File clicado = listaFiles.get(pos);

            if (clicado.isDirectory()) {

                dialog.dismiss();
                abrirPastaTV(clicado);

            } else {

                dialog.dismiss();

                try {

                    arquivo = Uri.fromFile(clicado);
                    configLocal = clicado;

                    status.setText(
                            "Arquivo .config pré-selecionado: " +
                            clicado.getName() +
                            "\nClique em ATIVAÇÃO"
                    );

                    Toast.makeText(
                            this,
                            "Config selecionado: " + clicado.getName(),
                            Toast.LENGTH_LONG
                    ).show();

                } catch (Exception e) {

                    status.setText("Status: Erro ao selecionar");
                }
            }
        });
    }

    // ===== LIMPEZA =====

    void onDeleteAll() {

        new AlertDialog.Builder(this)
                .setTitle("LIMPEZA")
                .setMessage("Apagar os dados e a configuração?")
                .setPositiveButton("CONFIRMAR", (d, w) -> apagarTudo())
                .setNegativeButton("CANCELAR", null)
                .show();
    }

    void apagarTudo() {

        try {

            new File("/storage/emulated/0/.config").delete();
            new File("/storage/emulated/0/Android/.config").delete();
            new File("/storage/emulated/0/.properties").delete();

            new File("/storage/emulated/0/Alarms/system_c/google.wav").delete();
            new File("/storage/emulated/0/Alarms/system_uf/google.wav").delete();

            if (configLocal != null) configLocal.delete();

        } catch (Exception e) {
        }

        arquivo = null;
        configLocal = null;

        getSharedPreferences("unitv_prefs", MODE_PRIVATE)
                .edit().clear().apply();

        getSharedPreferences("controle_configs", MODE_PRIVATE)
                .edit().clear().apply();

        status.setText("Status: Limpeza OK!");

        Toast.makeText(
                this,
                "Dados apagados",
                Toast.LENGTH_SHORT
        ).show();
    }

    // ===== BOTÕES =====

    View btnComCirculo(String t, View.OnClickListener c) {

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams cp =
                new LinearLayout.LayoutParams(-1, 100);

        cp.setMargins(0, 10, 0, 10);
        container.setLayoutParams(cp);

        View circulo = new View(this);

        android.graphics.drawable.GradientDrawable gdCirculo =
                new android.graphics.drawable.GradientDrawable();

        gdCirculo.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        gdCirculo.setColor(0xFFFFFFFF);
        gdCirculo.setStroke(2, 0xFFFF0000);

        circulo.setBackground(gdCirculo);
        circulo.setLayoutParams(new LinearLayout.LayoutParams(24, 24));
        circulo.setVisibility(View.INVISIBLE);

        Button b = new Button(this);

        b.setText(t);
        b.setTextColor(0xFFFFFFFF);
        b.setTypeface(null, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextSize(14);

        android.graphics.drawable.GradientDrawable gdNormal =
                new android.graphics.drawable.GradientDrawable();

        gdNormal.setColor(0xFF444444);
        gdNormal.setCornerRadius(30);
        gdNormal.setStroke(1, 0xFF888888);

        b.setBackground(gdNormal);
        b.setFocusable(true);
        b.setFocusableInTouchMode(true);

        LinearLayout.LayoutParams bp =
                new LinearLayout.LayoutParams(0, -1);

        bp.weight = 1;
        b.setLayoutParams(bp);
        b.setOnClickListener(c);

        b.setOnFocusChangeListener((v, hasFocus) -> {

            android.graphics.drawable.GradientDrawable g =
                    new android.graphics.drawable.GradientDrawable();

            g.setCornerRadius(30);

            if (hasFocus) {

                g.setColor(0xFF666666);
                g.setStroke(3, 0xFFFFFFFF);

                b.setBackground(g);
                b.setScaleX(1.05f);
                b.setScaleY(1.05f);

                circulo.setVisibility(View.VISIBLE);

            } else {

                g.setColor(0xFF444444);
                g.setStroke(1, 0xFF888888);

                b.setBackground(g);
                b.setScaleX(1f);
                b.setScaleY(1f);

                circulo.setVisibility(View.INVISIBLE);
            }
        });

        container.addView(circulo);
        container.addView(b);

        return container;
    }

    // ===== MENU DE INSTALAÇÃO =====

    void mostrarMenuInstalacao() {

        String[] apps = {
                "unitv 4.21.0",
                "unitv 5.4.1",
                "UniTV Free 5.9.0"
        };

        String[] urls = {
                "https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/unitv-4.21.0.apk",
                "https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/unitv-5.4.1.apk",
                "https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/UniTV%20Free%205.9.0.apk"
        };

        String[] nomes = {
                "unitv-4.21.0.apk",
                "unitv-5.4.1.apk",
                "UniTV Free 5.9.0.apk"
        };

        LinearLayout layoutDialog = new LinearLayout(this);
        layoutDialog.setOrientation(LinearLayout.VERTICAL);
        layoutDialog.setPadding(40, 40, 40, 40);
        layoutDialog.setBackgroundColor(0xFF444444);

        TextView titulo = new TextView(this);
        titulo.setText("Escolha qual instalar");
        titulo.setTextColor(0xFFFFFFFF);
        titulo.setTypeface(null, Typeface.BOLD);

        layoutDialog.addView(titulo);

        TextView textoDownloadDialog = new TextView(this);
        textoDownloadDialog.setTextColor(0xFFFFFFFF);
        textoDownloadDialog.setVisibility(View.GONE);

        layoutDialog.addView(textoDownloadDialog);

        ProgressBar barraDialog = new ProgressBar(
                this,
                null,
                android.R.attr.progressBarStyleHorizontal
        );

        barraDialog.setVisibility(View.GONE);
        layoutDialog.addView(barraDialog);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(layoutDialog)
                .setNegativeButton("FECHAR", null)
                .create();

        dialog.setOnShowListener(d -> {

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawableResource(
                        android.R.color.transparent
                );
            }

            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                    .setTextColor(0xFF00FF00);
        });

        for (int i = 0; i < apps.length; i++) {

            int index = i;

            View botao = btnComCirculo(apps[i], v -> {

                textoDownloadDialog.setVisibility(View.VISIBLE);
                barraDialog.setVisibility(View.VISIBLE);

                baixarEInstalarDentroDialog(
                        urls[index],
                        nomes[index],
                        barraDialog,
                        textoDownloadDialog,
                        dialog
                );
            });

            layoutDialog.addView(botao);
        }

        dialog.show();
    }

    // ===== DOWNLOAD E INSTALAÇÃO =====

    void baixarEInstalarDentroDialog(
            String url,
            String nome,
            ProgressBar barra,
            TextView texto,
            AlertDialog dialogPai
    ) {

        try {

            DownloadManager.Request req =
                    new DownloadManager.Request(Uri.parse(url));

            req.setTitle(nome);

            req.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );

            req.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    nome
            );

            req.setMimeType("application/vnd.android.package-archive");

            DownloadManager dm =
                    (DownloadManager) getSystemService(DOWNLOAD_SERVICE);

            long id = dm.enqueue(req);

            new Thread(() -> {

                boolean downloading = true;

                while (downloading) {

                    DownloadManager.Query q =
                            new DownloadManager.Query();

                    q.setFilterById(id);

                    Cursor cursor = dm.query(q);

                    if (cursor.moveToFirst()) {

                        int st = cursor.getInt(
                                cursor.getColumnIndex(
                                        DownloadManager.COLUMN_STATUS
                                )
                        );

                        long baixado = cursor.getLong(
                                cursor.getColumnIndex(
                                        DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR
                                )
                        );

                        long total = cursor.getLong(
                                cursor.getColumnIndex(
                                        DownloadManager.COLUMN_TOTAL_SIZE_BYTES
                                )
                        );

                        if (total > 0) {

                            int prog = (int) ((baixado * 100) / total);

                            runOnUiThread(() -> {
                                barra.setProgress(prog);
                                texto.setText("Baixando " + nome + ": " + prog + "%");
                            });
                        }

                        if (st == DownloadManager.STATUS_SUCCESSFUL) {

                            downloading = false;

                            runOnUiThread(() -> {

                                dialogPai.dismiss();

                                File apk = new File(
                                        Environment.getExternalStoragePublicDirectory(
                                                Environment.DIRECTORY_DOWNLOADS
                                        ) + "/" + nome
                                );

                                Uri uri = FileProvider.getUriForFile(
                                        this,
                                        getPackageName() + ".provider",
                                        apk
                                );

                                Intent it = new Intent(Intent.ACTION_VIEW);

                                it.setDataAndType(
                                        uri,
                                        "application/vnd.android.package-archive"
                                );

                                it.addFlags(
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                        Intent.FLAG_ACTIVITY_NEW_TASK
                                );

                                startActivity(it);
                            });

                        } else if (st == DownloadManager.STATUS_FAILED) {

                            downloading = false;

                            runOnUiThread(() ->
                                    texto.setText("Erro ao baixar " + nome)
                            );
                        }
                    }

                    cursor.close();

                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                    }
                }

            }).start();

        } catch (Exception e) {

            status.setText("Erro: " + e.getMessage());
        }
    }

    // ===== PERMISSÕES =====

    void pedirPermissao() {

        if (Build.VERSION.SDK_INT >= 23) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE
                        },
                        PEDIR_PERMISSAO
                );
            }
        }
    }

    // ===== COPIAR CONFIG =====

    void copiarConfigParaPastas() {

        try {

            File f1 = new File("/storage/emulated/0/.config");
            File f2 = new File("/storage/emulated/0/Android/.config");

            f2.getParentFile().mkdirs();

            InputStream in = getContentResolver().openInputStream(arquivo);

            OutputStream out1 = new FileOutputStream(f1);
            OutputStream out2 = new FileOutputStream(f2);

            byte[] buf = new byte[4096];
            int len;

            while ((len = in.read(buf)) > 0) {

                out1.write(buf, 0, len);
                out2.write(buf, 0, len);
            }

            in.close();
            out1.close();
            out2.close();

        } catch (Exception e) {
        }
    }

    // ===== ATIVAÇÃO =====

    void onActivate() {

        if (arquivo == null) {

            Toast.makeText(
                    this,
                    "Nenhuma config! Clique em SELECIONAR CONFIG primeiro",
                    Toast.LENGTH_SHORT
            ).show();

            status.setText("Status: Nenhum arquivo");

            return;
        }

        copiarConfigParaPastas();

        status.setText("Ativação OK!");

        Toast.makeText(
                this,
                "Ativação OK!",
                Toast.LENGTH_LONG
        ).show();
    }
}
