package com.ativadorjb.unitv;
import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.*;

public class MainActivity extends AppCompatActivity {
    TextView status;
    Uri arquivo;
    File configLocal;
    final int PEDIR_PERMISSAO = 100;
    final long TEMPO_LIBERADO = 10 * 60 * 1000; // 10 MINUTOS LIBERADO
    String siteCodigo = "https://magic-config-tokens.lovable.app/";
    WebView webViewAuto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawableResource(R.drawable.fundo_app);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30,30,30,30);
        l.setGravity(Gravity.CENTER);

        TextView titulo = new TextView(this);
        titulo.setText("ATIVADOR UNITV FREE");
        titulo.setTextSize(20);
        titulo.setTypeface(null, Typeface.BOLD);
        titulo.setTextColor(0xFFFFFFFF);
        titulo.setGravity(Gravity.CENTER);
        titulo.setPadding(0,30,0,30);
        android.graphics.drawable.GradientDrawable gdTitulo = new android.graphics.drawable.GradientDrawable();
        gdTitulo.setColor(0xDD000000); gdTitulo.setCornerRadius(12); gdTitulo.setStroke(2, 0xFFFF0000);
        titulo.setBackground(gdTitulo);
        l.addView(titulo);

        l.addView(btnComCirculo("LIMPEZA", v->onDeleteAll()));
        l.addView(btnComCirculo("Código.config", v->abrirSiteCodigo()));
        l.addView(btnComCirculo("ATIVAÇÃO", v->onActivate()));
        l.addView(btnComCirculo("INSTALAR APPS", v->mostrarMenuInstalacao()));
        l.addView(btnComCirculo("SAIR DO APP", v->finishAffinity()));

        TextView instrucoes = new TextView(this);
        instrucoes.setText("📋 PASSO A PASSO:\n\n1 - Faça a limpeza.\n2 - Desinstalar o UniTV Free (caso tenha instalado).\n3 - Coloque seu Código de Ativação.\n4 - Faça a Instalação do UniTV Free.\n\nObs: caso dê erro no seu UniTV Free\n• Desinstale o UniTV Free.\n• Faça a limpeza.\n• Instalar o UniTV Free 4.21.0 abra e vá até a parte que pede para atualizar.\n• Agora baixe e instale o UniTV Free 5.9.0 e seja Feliz.");
        instrucoes.setTextColor(0xFFFFFFFF); instrucoes.setPadding(25,25,25,25); instrucoes.setTypeface(null,Typeface.BOLD); instrucoes.setTextSize(13); instrucoes.setLineSpacing(6,1.15f);
        android.graphics.drawable.GradientDrawable gdCard = new android.graphics.drawable.GradientDrawable(); gdCard.setColor(0xEE000000); gdCard.setCornerRadius(15); gdCard.setStroke(1, 0xFF555555);
        instrucoes.setBackground(gdCard);
        l.addView(instrucoes);

        status = new TextView(this);
        status.setText("Status: Aguardando ação");
        status.setPadding(15,15,15,15); status.setTextColor(0xFF00FF00); status.setTextSize(14); status.setTypeface(null, Typeface.BOLD); status.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable gdLog = new android.graphics.drawable.GradientDrawable(); gdLog.setColor(0xFF000000); gdLog.setCornerRadius(12);
        status.setBackground(gdLog);
        l.addView(status);

        ScrollView sv = new ScrollView(this); sv.addView(l); setContentView(sv);
        pedirPermissao();
    }

    void onDeleteAll() { new AlertDialog.Builder(this).setTitle("LIMPEZA").setMessage("Apagar os dados e a configuração?").setPositiveButton("CONFIRMAR", (d, w) -> apagarTudo()).setNegativeButton("CANCELAR", null).show(); }
    void apagarTudo() {
        try{
            new File("/storage/emulated/0/.config").delete();
            new File("/storage/emulated/0/Android/.config").delete();
            new File("/storage/emulated/0/.properties").delete();
            new File("/storage/emulated/0/Alarms/system_c/google.wav").delete();
            new File("/storage/emulated/0/Alarms/system_uf/google.wav").delete();
            if (configLocal != null) configLocal.delete();
        }catch(Exception e){}
        arquivo = null; configLocal = null;
        getSharedPreferences("unitv_prefs", MODE_PRIVATE).edit().clear().apply();
        getSharedPreferences("controle_configs", MODE_PRIVATE).edit().clear().apply();
        status.setText("Status: Limpeza OK!"); Toast.makeText(this, "Dados apagados", Toast.LENGTH_SHORT).show();
    }

    // ===== VALIDAÇÃO 10 MINUTOS =====
    boolean codigoExpirado(String c){
        try{
            File f = new File(getFilesDir(),"used_codes.txt");
            if(!f.exists()) return false;
            long agora = System.currentTimeMillis();
            BufferedReader br = new BufferedReader(new FileReader(f));
            String linha;
            while((linha=br.readLine())!=null){
                linha=linha.trim();
                if(linha.isEmpty()) continue;
                String[] partes = linha.split("\\|");
                if(partes.length<2) continue;
                String codSalvo = partes[0];
                if(!codSalvo.equals(c.trim())) continue;
                long tempoSalvo = Long.parseLong(partes[1]);
                br.close();
                if(agora - tempoSalvo > TEMPO_LIBERADO){
                    return true; // passou de 10 min -> bloqueado
                } else {
                    return false; // ainda dentro dos 10 min -> liberado
                }
            }
            br.close();
        }catch(Exception e){}
        return false;
    }

    boolean codigoJaExiste(String c){
        try{
            File f = new File(getFilesDir(),"used_codes.txt");
            if(!f.exists()) return false;
            BufferedReader br = new BufferedReader(new FileReader(f));
            String linha;
            while((linha=br.readLine())!=null){
                String[] partes = linha.trim().split("\\|");
                if(partes[0].equals(c.trim())){ br.close(); return true; }
            }
            br.close();
        }catch(Exception e){}
        return false;
    }

    void salvarCodigoPrimeiraVez(String c){
        try{
            if(codigoJaExiste(c)) return; // não atualiza tempo
            File f = new File(getFilesDir(),"used_codes.txt");
            long agora = System.currentTimeMillis();
            FileWriter fw = new FileWriter(f, true);
            fw.append(c.trim() + "|" + agora + "\n");
            fw.close();
        }catch(Exception e){}
    }

    void abrirSiteCodigo(){
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(50,40,50,40); layout.setBackgroundColor(0xFFFFFFFF);
        TextView t = new TextView(this); t.setText("Código.config - 10 min liberado"); t.setTextColor(0xFF000000); t.setTextSize(18); t.setTypeface(null,Typeface.BOLD); t.setGravity(Gravity.CENTER); layout.addView(t);
        EditText inputCodigo = new EditText(this); inputCodigo.setHint("000000"); inputCodigo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); inputCodigo.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)}); inputCodigo.setTextSize(32); inputCodigo.setGravity(Gravity.CENTER); inputCodigo.setTypeface(null,Typeface.BOLD);
        android.graphics.drawable.GradientDrawable gdInput = new android.graphics.drawable.GradientDrawable(); gdInput.setColor(0xFFEEEEEE); gdInput.setCornerRadius(15); gdInput.setStroke(2,0xFFFF0000); inputCodigo.setBackground(gdInput); inputCodigo.setPadding(20,35,20,35); layout.addView(inputCodigo);
        TextView logDialog = new TextView(this); logDialog.setText("Aguardando código..."); logDialog.setTextColor(0xFF000000); logDialog.setTextSize(14); logDialog.setPadding(15,15,15,15); logDialog.setGravity(Gravity.CENTER); layout.addView(logDialog);
        webViewAuto = new WebView(this); webViewAuto.getSettings().setJavaScriptEnabled(true); webViewAuto.getSettings().setDomStorageEnabled(true); webViewAuto.getSettings().setAllowFileAccess(true); webViewAuto.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(webViewAuto, true); webViewAuto.setWebChromeClient(new WebChromeClient()); webViewAuto.addJavascriptInterface(new JSInterface(logDialog), "Android"); webViewAuto.setLayoutParams(new LinearLayout.LayoutParams(1, 1)); layout.addView(webViewAuto);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(layout).setPositiveButton("BAIXAR AUTOMÁTICO", null).setNegativeButton("FECHAR", null).create(); dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String codigo = inputCodigo.getText().toString().trim();
            if(codigo.length()<4){ inputCodigo.setError("Digite o código"); return; }
            if(codigoExpirado(codigo)){
                logDialog.setText("ACESSO BLOQUEADO!\nCódigo "+codigo+" expirou.\nFoi liberado por 10 min e agora bloqueou pra sempre.");
                logDialog.setTextColor(0xFFFF0000);
                status.setText("Status: Acesso bloqueado - expirado");
                Toast.makeText(this,"Acesso bloqueado - 10 min expirado",Toast.LENGTH_LONG).show();
                return;
            }
            logDialog.setText("Verificando código...\nCódigo: "+codigo); logDialog.setTextColor(0xFF000000); status.setText("Status: Verificando código "+codigo+"..."); buscarCodigoDireto(codigo, logDialog);
        });
    }

    class JSInterface {
        TextView logView; JSInterface(TextView v){ logView=v; }
        @JavascriptInterface
        public void receberBase64(String base64Data, String codigo) {
            runOnUiThread(() -> {
                try{
                    logView.setText("Download concluído...\nSalvando...");
                    byte[] dados = Base64.decode(base64Data, Base64.DEFAULT);
                    File fileDestino = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), codigo+".config");
                    FileOutputStream fos = new FileOutputStream(fileDestino); fos.write(dados); fos.close();
                    arquivo = Uri.fromFile(fileDestino); configLocal = fileDestino;
                    copiarConfigParaPastas();
                    salvarCodigoPrimeiraVez(codigo);
                    logView.setText("✓ Arquivo pré-instalado\nAguardando ativação");
                    logView.setTextColor(0xFF000000);
                    status.setText("Arquivo pré-instalado\nAguardando ativação");
                    Toast.makeText(MainActivity.this,"Pré-instalado! Clique em ATIVAÇÃO",Toast.LENGTH_LONG).show();
                }catch(Exception e){ logView.setText("Erro ao salvar: "+e.getMessage()); status.setText("Status: Erro: "+e.getMessage()); }
            });
        }
    }

    void iniciarWebViewDownload(String codigo, TextView logDialog, AlertDialog dialogPai){
        webViewAuto.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            runOnUiThread(()-> { logDialog.setText("Download concluído...\nProcessando..."); status.setText("Status: Download concluído"); });
            String jsDownload = "(function(){ let url='"+url.replace("'", "\\'")+"'; let cod='"+codigo+"'; fetch(url).then(r=>r.blob()).then(b=>{ let rd=new FileReader(); rd.onloadend=()=>{ var b64=rd.result.split(',')[1]; Android.receberBase64(b64,cod); }; rd.readAsDataURL(b); }).catch(e=>{}); })();";
            webViewAuto.evaluateJavascript(jsDownload, null);
        });
        webViewAuto.setWebViewClient(new WebViewClient(){
            boolean jaBaixou=false;
            boolean ehArquivo(String u){ return u!=null && (u.contains("/storage/v1/object/") || u.toLowerCase().contains(".config")); }
            void pegar(WebView view, String u){
                if(jaBaixou) return; jaBaixou=true;
                view.stopLoading();
                logDialog.setText("Baixando arquivo...");
                baixarDireto(u, codigo, logDialog);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String u){
                if(ehArquivo(u)){ pegar(view,u); return true; } return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req){
                String u=req.getUrl().toString();
                if(ehArquivo(u)){ pegar(view,u); return true; } return false;
            }
            @Override public void onPageStarted(WebView view, String u, android.graphics.Bitmap f){
                if(ehArquivo(u)){ pegar(view,u); return; }
                super.onPageStarted(view,u,f);
            }
            @Override public void onPageFinished(WebView view, String url){
                if(ehArquivo(url)) return;
                logDialog.setText("Site carregado...\nInserindo código...");
                String js = "(function(){var cod='"+codigo+"',n=0;var t=setInterval(function(){n++;"
                 + "var inp=[].slice.call(document.querySelectorAll('input')).filter(function(i){return i.type!='hidden'})[0];"
                 + "if(!inp){if(n>40)clearInterval(t);return;}"
                 + "var s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;s.call(inp,cod);"
                 + "inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));"
                 + "var b=[].slice.call(document.querySelectorAll('button,[role=button],a')).filter(function(x){var y=(x.innerText||'').toLowerCase();return /baixar|download|gerar|ativar/.test(y)})[0];"
                 + "if(b){clearInterval(t);setTimeout(function(){b.click()},800);}},500);})();";
                view.evaluateJavascript(js, null);
            }
        });
        webViewAuto.loadUrl(siteCodigo);
    }

    // ===== PEDE O ARQUIVO DIRETO PRO SITE (SEM WEBVIEW - FUNCIONA EM TV BOX) =====
    final String SERVIDOR_CODIGO = "https://magic-config-tokens.lovable.app/_serverFn/db9e345b975b68f20f6d648d3e581ee7299ac414c92135630747947bc3a3a0b6";
    void buscarCodigoDireto(String codigo, TextView logView){
        new Thread(()->{
            try{
                java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(SERVIDOR_CODIGO).openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true);
                c.setConnectTimeout(20000); c.setReadTimeout(30000);
                c.setRequestProperty("Content-Type","application/json");
                c.setRequestProperty("Accept","application/json");
                c.setRequestProperty("x-tsr-serverFn","true");
                c.setRequestProperty("Origin","https://magic-config-tokens.lovable.app");
                String corpo="{\"t\":{\"t\":10,\"i\":0,\"p\":{\"k\":[\"data\"],\"v\":[{\"t\":10,\"i\":1,\"p\":{\"k\":[\"code\"],\"v\":[{\"t\":1,\"s\":\""+codigo+"\"}]},\"o\":0}]},\"o\":0},\"f\":127,\"m\":[]}";
                OutputStream os=c.getOutputStream(); os.write(corpo.getBytes("UTF-8")); os.close();
                int http=c.getResponseCode();
                InputStream in = http>=400 ? c.getErrorStream() : c.getInputStream();
                ByteArrayOutputStream bo=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
                if(in!=null){ while((n=in.read(buf))>0) bo.write(buf,0,n); in.close(); }
                String resp=bo.toString("UTF-8");
                // pega todos os textos da resposta
                java.util.regex.Matcher m=java.util.regex.Pattern.compile("\"s\":\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(resp);
                String url=null, erro=null;
                while(m.find()){
                    String s=desescapar(m.group(1));
                    if(s.startsWith("http")){ if(url==null) url=s; }
                    else if(erro==null && !s.endsWith(".config")) erro=s;
                }
                if(url!=null){
                    final String u=url;
                    runOnUiThread(()->{ logView.setText("Código OK!\nBaixando arquivo..."); status.setText("Status: Baixando arquivo..."); });
                    baixarDireto(u, codigo, logView);
                } else {
                    final String msg = erro!=null ? erro : ("Resposta inesperada do site (HTTP "+http+")");
                    runOnUiThread(()->{ logView.setText(msg); logView.setTextColor(0xFFFF0000); status.setText("Status: "+msg); });
                }
            }catch(Exception e){
                runOnUiThread(()->{ logView.setText("Erro de conexão: "+e.getMessage()); logView.setTextColor(0xFFFF0000); status.setText("Status: Erro de conexão"); });
            }
        }).start();
    }

    String desescapar(String s){
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch=='\\' && i+1<s.length()){
                char nx=s.charAt(++i);
                if(nx=='u' && i+4<s.length()){ sb.append((char)Integer.parseInt(s.substring(i+1,i+5),16)); i+=4; }
                else if(nx=='n') sb.append('\n');
                else if(nx=='t') sb.append('\t');
                else sb.append(nx);
            } else sb.append(ch);
        }
        return sb.toString();
    }

    void baixarDireto(String u, String codigo, TextView logView){
        new Thread(()->{
            try{
                java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(u).openConnection();
                c.setConnectTimeout(20000); c.setReadTimeout(30000);
                InputStream in=c.getInputStream(); ByteArrayOutputStream bo=new ByteArrayOutputStream();
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) bo.write(buf,0,n); in.close();
                String b64=Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                new JSInterface(logView).receberBase64(b64, codigo);
            }catch(Exception e){
                runOnUiThread(()->{ logView.setText("Erro no download: "+e.getMessage()); status.setText("Status: Erro no download"); });
            }
        }).start();
    }

    View btnComCirculo(String t, View.OnClickListener c){
        LinearLayout container = new LinearLayout(this); container.setOrientation(LinearLayout.HORIZONTAL); container.setGravity(Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,110); cp.setMargins(0,15,0,15); container.setLayoutParams(cp);
        View circulo = new View(this); android.graphics.drawable.GradientDrawable gdCirculo = new android.graphics.drawable.GradientDrawable(); gdCirculo.setShape(android.graphics.drawable.GradientDrawable.OVAL); gdCirculo.setColor(0xFFFFFFFF); gdCirculo.setStroke(2,0xFFFF0000); circulo.setBackground(gdCirculo); circulo.setLayoutParams(new LinearLayout.LayoutParams(24,24)); circulo.setVisibility(View.INVISIBLE);
        Button b = new Button(this); b.setText(t); b.setTextColor(0xFFFFFFFF); b.setTypeface(null,Typeface.BOLD); b.setAllCaps(false); b.setTextSize(14); android.graphics.drawable.GradientDrawable gdNormal = new android.graphics.drawable.GradientDrawable(); gdNormal.setColor(0xFF444444); gdNormal.setCornerRadius(30); gdNormal.setStroke(1, 0xFF888888); b.setBackground(gdNormal); b.setFocusable(true); b.setFocusableInTouchMode(true); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,-1); bp.weight=1; b.setLayoutParams(bp); b.setOnClickListener(c);
        b.setOnFocusChangeListener((v,hasFocus)->{ android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(); g.setCornerRadius(30); if(hasFocus){ g.setColor(0xFF666666); g.setStroke(3,0xFFFFFFFF); b.setBackground(g); b.setScaleX(1.05f); b.setScaleY(1.05f); circulo.setVisibility(View.VISIBLE); } else { g.setColor(0xFF444444); g.setStroke(1,0xFF888888); b.setBackground(g); b.setScaleX(1f); b.setScaleY(1f); circulo.setVisibility(View.INVISIBLE); } });
        container.addView(circulo); container.addView(b); return container;
    }

    void mostrarMenuInstalacao(){
        String[] apps={"unitv 4.21.0","unitv 5.4.1","UniTV Free 5.9.0"};
        String[] urls={"https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/unitv-4.21.0.apk","https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/unitv-5.4.1.apk","https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/UniTV%20Free%205.9.0.apk"};
        String[] nomes={"unitv-4.21.0.apk","unitv-5.4.1.apk","UniTV Free 5.9.0.apk"};
        LinearLayout layoutDialog = new LinearLayout(this); layoutDialog.setOrientation(LinearLayout.VERTICAL); layoutDialog.setPadding(40,40,40,40);
        TextView titulo = new TextView(this); titulo.setText("Escolha qual instalar"); titulo.setTextColor(0xFF000000); titulo.setTypeface(null,Typeface.BOLD); layoutDialog.addView(titulo);
        TextView textoDownloadDialog = new TextView(this); textoDownloadDialog.setVisibility(View.GONE); layoutDialog.addView(textoDownloadDialog);
        ProgressBar barraDialog = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); barraDialog.setVisibility(View.GONE); layoutDialog.addView(barraDialog);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(layoutDialog).setNegativeButton("FECHAR",null).create();
        for(int i=0;i<apps.length;i++){ int index=i; View botao = btnComCirculo(apps[i], v->{ textoDownloadDialog.setVisibility(View.VISIBLE); barraDialog.setVisibility(View.VISIBLE); baixarEInstalarDentroDialog(urls[index], nomes[index], barraDialog, textoDownloadDialog, dialog); }); layoutDialog.addView(botao); }
        dialog.show();
    }

    void baixarEInstalarDentroDialog(String url, String nome, ProgressBar barra, TextView texto, AlertDialog dialogPai){
        try{
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url)); req.setTitle(nome); req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, nome); req.setMimeType("application/vnd.android.package-archive");
            DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE); long id = dm.enqueue(req);
            new Thread(()->{
                boolean downloading=true;
                while(downloading){
                    DownloadManager.Query q = new DownloadManager.Query(); q.setFilterById(id); Cursor cursor = dm.query(q);
                    if(cursor.moveToFirst()){
                        int st = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
                        long baixado = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                        long total = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                        if(total>0){ int prog=(int)((baixado*100)/total); runOnUiThread(()->{ barra.setProgress(prog); texto.setText("Baixando "+nome+": "+prog+"%"); }); }
                        if(st==DownloadManager.STATUS_SUCCESSFUL){ downloading=false; runOnUiThread(()->{ dialogPai.dismiss(); File apk = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+"/"+nome); Uri uri = FileProvider.getUriForFile(this,getPackageName()+".provider",apk); Intent it = new Intent(Intent.ACTION_VIEW); it.setDataAndType(uri,"application/vnd.android.package-archive"); it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it); }); } else if(st==DownloadManager.STATUS_FAILED){ downloading=false; }
                    }
                    cursor.close(); try{Thread.sleep(500);}catch(Exception e){}
                }
            }).start();
        } catch(Exception e){ status.setText("Erro: "+e.getMessage()); }
    }

    boolean temAcessoTotal(){
        try{ return (Boolean) Environment.class.getMethod("isExternalStorageManager").invoke(null); }
        catch(Exception e){ return true; }
    }
    void pedirPermissao(){
        if(Build.VERSION.SDK_INT>=23){ if(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){ ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, PEDIR_PERMISSAO); } }
        if(Build.VERSION.SDK_INT>=30 && !temAcessoTotal()){
            try{ startActivity(new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", Uri.parse("package:"+getPackageName()))); }
            catch(Exception e){ try{ startActivity(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION")); }catch(Exception e2){} }
        }
    }
    void copiarConfigParaPastas(){ try{ File f1 = new File("/storage/emulated/0/.config"); File f2 = new File("/storage/emulated/0/Android/.config"); f2.getParentFile().mkdirs(); InputStream in = getContentResolver().openInputStream(arquivo); OutputStream out1 = new FileOutputStream(f1); OutputStream out2 = new FileOutputStream(f2); byte[] buf = new byte[4096]; int len; while((len=in.read(buf))>0){ out1.write(buf,0,len); out2.write(buf,0,len); } in.close(); out1.close(); out2.close(); } catch(Exception e){ status.setText("Erro ao copiar: "+e.getMessage()); } }
    void onActivate(){
        if(arquivo==null){ Toast.makeText(this,"Nenhuma config! Digite o código primeiro",Toast.LENGTH_SHORT).show(); status.setText("Status: Nenhum arquivo"); return; }
        copiarConfigParaPastas();
        status.setText("Ativação OK!");
        Toast.makeText(this, "Ativação OK!", Toast.LENGTH_LONG).show();
        abrirUnitv();
    }
    void abrirUnitv(){ try{ Intent i = getPackageManager().getLaunchIntentForPackage("com.integration.unitvsiptv"); if(i!=null) startActivity(i); } catch(Exception e){} }
    @Override protected void onActivityResult(int r,int s,Intent d){ super.onActivityResult(r,s,d); }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){ super.onRequestPermissionsResult(requestCode,permissions,grantResults); }
}