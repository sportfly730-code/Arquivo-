package com.erik.macautomation;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class FloatingControlService extends Service {

    private WindowManager windowManager;
    private View bubbleView;
    private WindowManager.LayoutParams params;

    private TextView txtBubbleMac, txtBubbleStatus, txtBubbleCounter;
    private TextView txtBubbleDaysInfo, txtBubbleLog;
    private TextView txtBubbleCounterZero;
    private android.widget.CheckBox chkBubbleOnlyZero;
    private volatile boolean onlyZeroDays = false;
    private android.widget.EditText edtBubbleZeroTarget;
    // v24: sempre limpa os dados do UniTV (a caixinha foi removida)
    private final boolean clearUnitvData = true;
    // v24: quantas configs 0 dias salvar antes de pausar (0 = não para)
    private volatile int zeroTarget = 0;
    private int savedZeroCount = 0;
    private Button btnBubbleStop;

    private boolean isRunning = false;
    private Thread automationThread;
    private int savedConfigsCount = 0;
    private String lastDaysActive = "--";

    // Últimas 6 linhas de log
    private final List<String> logLines = new ArrayList<>();
    private static final int MAX_LOG_LINES = 6;

    private String baseMac, coordXStr, coordYStr, delayStr;

    private static final String TARGET_PACKAGE = "com.integration.unitvsiptv";
    private static final String PREFS_PATH = "/data/data/" + TARGET_PACKAGE + "/shared_prefs/cache.config.xml";
    private static final String CHANNEL_ID = "willbootjb_channel";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // Criar notification channel e foreground notification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "WillbootJB Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);

            Notification notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("WillbootJB")
                    .setContentText("Automação em execução...")
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .build();
            startForeground(1, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Licença: sem chave conferida nesta abertura, a bolha não roda
        if (!LicenseGuard.isSessionOk()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE);
            else stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) {
            baseMac = intent.getStringExtra("baseMac");
            coordXStr = intent.getStringExtra("coordX");
            coordYStr = intent.getStringExtra("coordY");
            delayStr = intent.getStringExtra("delay");
        }

        if (!isRunning && baseMac != null) {
            startBubbleWindow();
            startAutomation();
        }

        return START_NOT_STICKY;
    }

    private void addLog(String msg) {
        synchronized (logLines) {
            logLines.add(msg);
            if (logLines.size() > MAX_LOG_LINES) {
                logLines.remove(0);
            }
        }
        if (txtBubbleLog != null) {
            txtBubbleLog.post(() -> {
                synchronized (logLines) {
                    StringBuilder sb = new StringBuilder();
                    for (String line : logLines) {
                        if (sb.length() > 0) sb.append("\n");
                        sb.append("▸ ").append(line);
                    }
                    txtBubbleLog.setText(sb.toString());
                }
            });
        }
    }

    private void startBubbleWindow() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble_layout, null);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 30;
        params.y = 30;

        windowManager.addView(bubbleView, params);

        txtBubbleMac = bubbleView.findViewById(R.id.txtBubbleMac);
        txtBubbleStatus = bubbleView.findViewById(R.id.txtBubbleStatus);
        txtBubbleCounter = bubbleView.findViewById(R.id.txtBubbleCounter);
        txtBubbleDaysInfo = bubbleView.findViewById(R.id.txtBubbleDaysInfo);
        txtBubbleLog = bubbleView.findViewById(R.id.txtBubbleLog);
        txtBubbleCounterZero = bubbleView.findViewById(R.id.txtBubbleCounterZero);
        chkBubbleOnlyZero = bubbleView.findViewById(R.id.chkBubbleOnlyZero);
        if (chkBubbleOnlyZero != null) {
            chkBubbleOnlyZero.setOnCheckedChangeListener((b, checked) -> {
                onlyZeroDays = checked;
                addLog(checked ? "Modo: salvar só 0 dias" : "Modo: salvar todas");
            });
        }
        edtBubbleZeroTarget = bubbleView.findViewById(R.id.edtBubbleZeroTarget);
        if (edtBubbleZeroTarget != null) {
            // A bolha não recebe teclado; ao tocar no campo libera o teclado, ao confirmar devolve.
            edtBubbleZeroTarget.setOnTouchListener((v, ev) -> {
                if (ev.getAction() == android.view.MotionEvent.ACTION_UP) {
                    params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    windowManager.updateViewLayout(bubbleView, params);
                    v.requestFocus();
                    android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(v, 0);
                }
                return false;
            });
            edtBubbleZeroTarget.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
            edtBubbleZeroTarget.setOnEditorActionListener((v, actionId, ev) -> {
                android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                v.clearFocus();
                params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                windowManager.updateViewLayout(bubbleView, params);
                addLog(zeroTarget > 0 ? "Pausa ao salvar " + zeroTarget + " config(s) 0 dias" : "Sem pausa por 0 dias");
                return true;
            });
            edtBubbleZeroTarget.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence c, int a, int b, int d) {}
                public void onTextChanged(CharSequence c, int a, int b, int d) {}
                public void afterTextChanged(android.text.Editable e) {
                    try { zeroTarget = Integer.parseInt(e.toString().trim()); }
                    catch (Exception ex) { zeroTarget = 0; }
                }
            });
        }
        btnBubbleStop = bubbleView.findViewById(R.id.btnBubbleStop);

        btnBubbleStop.setOnClickListener(v -> {
            stopAutomation();
            stopSelf();
        });

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(bubbleView, params);
                        return true;
                }
                return false;
            }
        });
    }

    private void startAutomation() {
        // Usa o MAC exatamente como foi digitado (com ou sem ":"), e só muda os 3 últimos números
        String hexOnly = baseMac.toUpperCase().replaceAll("[^0-9A-F]", "");
        while (hexOnly.length() < 12) hexOnly = hexOnly + "0";
        if (hexOnly.length() > 12) hexOnly = hexOnly.substring(0, 12);
        final String fixedPart = hexOnly.substring(0, 9);          // parte que não muda
        final int startEnd = Integer.parseInt(hexOnly.substring(9), 16); // 3 últimos números

        int x = Integer.parseInt(coordXStr);
        int y = Integer.parseInt(coordYStr);
        int delay = Integer.parseInt(delayStr);

        // v30: continua de onde parou na última vez (para o mesmo MAC digitado)
        final android.content.SharedPreferences progPrefs = getSharedPreferences("mac_progresso", MODE_PRIVATE);
        final String progKey = "ultimo_" + hexOnly;
        final int resumeFrom = progPrefs.getInt(progKey, 0);
        if (resumeFrom > 0 && resumeFrom < 4096) {
            addLog("Continuando do final " + String.format("%03X", (startEnd + resumeFrom) % 4096));
        }

        isRunning = true;

        automationThread = new Thread(() -> {
            // Passa pelas 4096 combinações dos 3 últimos números, continuando de onde parou
            for (int n = (resumeFrom < 4096 ? resumeFrom : 0); n < 4096; n++) {
                {
                    if (!isRunning) return;
                    progPrefs.edit().putInt(progKey, n).apply();

                    String h = fixedPart + String.format("%03X", (startEnd + n) % 4096);
                    StringBuilder sb = new StringBuilder();
                    for (int k = 0; k < 12; k += 2) {
                        if (k > 0) sb.append(':');
                        sb.append(h, k, k + 2);
                    }
                    String fullMac = sb.toString();

                    try {
                        addLog("Limpando arquivos...");
                        updateBubbleInfo(fullMac, "Limpando arquivos...");

                        addLog("Injetando XML p/ " + fullMac.substring(fullMac.length() - 5));
                        updateBubbleInfo(fullMac, "Injetando XML...");
                        // Só o MAC. Os dados da conta antiga (user_id, device_id, key_n_bt, token)
                        // NÃO vão mais no XML, para o UniTV gerar uma conta nova a cada MAC.
                        String xmlContent = "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>\n" +
                                "<map>\n" +
                                "    <string name=\"KEY_SP_SN\">" + fullMac + "</string>\n" +
                                "    <string name=\"SP_SN_BACKUP\">" + fullMac + ",1</string>\n" +
                                "    <string name=\"key_renew_flag\">0</string>\n" +
                                "</map>";

                        // v23: no emulador o app não consegue criar a pasta WillbootJB no armazenamento.
                        // Agora grava primeiro na pasta interna do próprio app (sempre funciona)
                        // e, por garantia, cria a pasta WillbootJB com root.
                        runRoot("mkdir -p /storage/emulated/0/WillbootJB/Configs && chmod 777 /storage/emulated/0/WillbootJB");
                        File tempFile = new File(getCacheDir(), "temp_cache.xml");
                        FileOutputStream fos = new FileOutputStream(tempFile);
                        fos.write(xmlContent.getBytes(StandardCharsets.UTF_8));
                        fos.close();
                        tempFile.setReadable(true, false);

                        addLog("Aplicando MAC na rede...");
                        updateBubbleInfo(fullMac, "Aplicando MAC na rede...");
                        // v25: no emulador, derrubar wlan0/eth0 desliga o Wi-Fi e a internet.
                        // No emulador o MAC vai só no cache.config.xml do UniTV (não mexe na rede).
                        if (isEmulator()) {
                            addLog("Emulador: MAC só no UniTV (Wi-Fi não é desligado)");
                        } else {
                            runRoot("ip link set dev wlan0 down; ip link set dev wlan0 address " + fullMac + "; ip link set dev wlan0 up");
                            runRoot("ip link set dev eth0 down; ip link set dev eth0 address " + fullMac + "; ip link set dev eth0 up");
                        }
                        // Garante que o Wi-Fi fica ligado
                        runRoot("svc wifi enable");
                        Thread.sleep(1500);

                        // ===== Parar o UniTV e trocar SOMENTE o cache.config.xml =====
                        addLog("Forçando parada do UniTV...");
                        updateBubbleInfo(fullMac, "Trocando cache.config.xml...");
                        runRoot("am force-stop " + TARGET_PACKAGE);
                        Thread.sleep(1500);

                        // v16: sem limpeza de .config, .properties e Alarms
                        // 1b) Opção da bolha: limpar TODOS os dados do UniTV (igual era antes)
                        if (clearUnitvData) {
                            addLog("Limpando dados do UniTV...");
                            updateBubbleInfo(fullMac, "Limpando dados do UniTV...");
                            runRoot("pm clear " + TARGET_PACKAGE);
                            Thread.sleep(800);
                            // Já libera as permissões, para o Android não perguntar ao abrir
                            grantAllPermissions();
                        }
                        // 2) Apaga o cache.config.xml antigo
                        runRoot("rm -f " + PREFS_PATH);
                        runRoot("mkdir -p /data/data/" + TARGET_PACKAGE + "/shared_prefs");
                        runRoot("chown $(stat -c '%U:%G' /data/data/" + TARGET_PACKAGE + ") /data/data/" + TARGET_PACKAGE + "/shared_prefs");
                        runRoot("chmod 771 /data/data/" + TARGET_PACKAGE + "/shared_prefs");
                        runRoot("restorecon -R /data/data/" + TARGET_PACKAGE + "/shared_prefs");
                        // 3) Insere o novo cache.config.xml com o novo MAC
                        runRoot("cp " + tempFile.getAbsolutePath() + " " + PREFS_PATH);
                        runRoot("chmod 660 " + PREFS_PATH);
                        runRoot("chown $(stat -c '%U:%G' /data/data/" + TARGET_PACKAGE + ") " + PREFS_PATH);
                        runRoot("restorecon " + PREFS_PATH);
                        addLog("cache.config.xml trocado");
                        updateBubbleInfo(fullMac, "Abrindo UniTV Free...");

                        Thread.sleep(300);

                        // Usar intent com launcher ao invés de activity específica
                        String launchResult = runRootWithOutput(
                                "monkey -p " + TARGET_PACKAGE + " -c android.intent.category.LAUNCHER 1"
                        );
                        addLog("Launch: " + (launchResult.contains("Events injected") ? "OK" : "falhou"));

                        // Se monkey falhar, tentar am start com intent genérico
                        if (!launchResult.contains("Events injected")) {
                            runRoot("am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER " + TARGET_PACKAGE);
                            addLog("Tentando am start fallback...");
                        }

                        Thread.sleep(300);

                        // Verificar se o app realmente abriu
                        String focusedWindow = runRootWithOutput("dumpsys window windows | grep -i 'mCurrentFocus'");
                        boolean appOpened = focusedWindow.contains(TARGET_PACKAGE);
                        addLog(appOpened ? "UniTV aberto ✓" : "UniTV NÃO abriu ✗");

                        if (!appOpened) {
                            // Tentar mais uma vez
                            Thread.sleep(500);
                            runRoot("monkey -p " + TARGET_PACKAGE + " -c android.intent.category.LAUNCHER 1");
                            Thread.sleep(1500);
                        }

                        // Pula as telas de permissão / entrada que aparecem depois de limpar
                        if (clearUnitvData) {
                            skipStartupScreens(fullMac);
                        }
                        // Dois cliques no meio da tela para passar as duas telas de entrada
                        tapIntroScreens(fullMac);

                        addLog("Aguardando " + delay + "s...");
                        updateBubbleInfo(fullMac, "Carregando (" + delay + "s)...");
                        Thread.sleep(delay * 1000L);

                        // Limpa leituras antigas (tela inicial etc.) antes de abrir o perfil
                        if (AutoAccessibilityService.getInstance() != null) {
                            AutoAccessibilityService.getInstance().clearDetectedDays();
                        }

                        addLog("Clicando perfil (" + x + "," + y + ")...");
                        updateBubbleInfo(fullMac, "Clicando no perfil...");
                        runRoot("input tap " + x + " " + y);

                        addLog("Lendo dias ativos...");
                        updateBubbleInfo(fullMac, "Lendo dias ativos...");

                        // Espera até 10s pela leitura dos dias (checa a cada 500ms)
                        String detectedDays = null;
                        for (int t = 0; t < 20 && isRunning; t++) {
                            Thread.sleep(500);
                            AutoAccessibilityService acc = AutoAccessibilityService.getInstance();
                            if (acc == null) break;
                            String d = acc.getLastDetectedDays();
                            if (d != null && !d.isEmpty()) { detectedDays = d; break; }
                        }

                        if (detectedDays == null) {
                            // Perfil não abriu ou dias não lidos: NÃO salva a config
                            addLog("Perfil não abriu - config descartada ✗");
                            updateBubbleInfo(fullMac, "Descartada (sem leitura)");
                            Thread.sleep(1000);
                            continue;
                        }
                        AutoAccessibilityService.getInstance().clearDetectedDays();

                        boolean isZero = "0".equals(detectedDays.trim());
                        if (onlyZeroDays && !isZero) {
                            addLog("Ignorada (" + detectedDays + " dias) - modo só 0 dias");
                            updateBubbleInfo(fullMac, "Ignorada: " + detectedDays + " Dias");
                            Thread.sleep(1000);
                            continue;
                        }

                        lastDaysActive = detectedDays;
                        addLog("Salvo: " + detectedDays + " dias - " + fullMac.substring(fullMac.length() - 5));
                        updateBubbleInfo(fullMac, "Salvo: " + detectedDays + " Dias");
                        saveConfigWithDays(fullMac, detectedDays, tempFile);

                        if (isZero) savedZeroCount++; else savedConfigsCount++;
                        updateCounterAndDays();

                        // v24: chegou na quantidade de configs 0 dias pedida -> pausa
                        if (isZero && zeroTarget > 0 && savedZeroCount >= zeroTarget) {
                            addLog("PAUSADO: " + savedZeroCount + " config(s) 0 dias salvas");
                            updateBubbleInfo(fullMac, "Pausado: meta de 0 dias");
                            isRunning = false;
                            return;
                        }

                        Thread.sleep(1500);

                    } catch (InterruptedException e) {
                        return;
                    } catch (Exception e) {
                        addLog("ERRO: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
            progPrefs.edit().remove(progKey).apply();
            addLog("Automação concluída!");
            stopAutomation();
        });
        automationThread.start();
    }

    private void updateCounterAndDays() {
        if (txtBubbleCounter != null) {
            txtBubbleCounter.post(() -> txtBubbleCounter.setText("Configs Salvas: " + savedConfigsCount));
        }
        if (txtBubbleCounterZero != null) {
            txtBubbleCounterZero.post(() -> txtBubbleCounterZero.setText("Configs 0 Dias: " + savedZeroCount));
        }
        if (txtBubbleDaysInfo != null) {
            txtBubbleDaysInfo.post(() -> txtBubbleDaysInfo.setText("Última config: " + lastDaysActive + " dias"));
        }
    }

    private void updateBubbleInfo(String mac, String status) {
        if (txtBubbleMac != null && txtBubbleStatus != null) {
            txtBubbleMac.post(() -> {
                txtBubbleMac.setText("MAC: " + mac);
                txtBubbleStatus.setText("Status: " + status);
            });
        }
    }

    // 0 dias -> Salvas0Dias; 1-51 -> Salvas_1a51; 52-103 -> Salvas_52a103; 104-155 ... (blocos de 52)
    private String pastaPorDias(String days) {
        int d;
        try { d = Integer.parseInt(days.trim()); } catch (Exception e) { return "WillbootJB/Configs/Salvas"; }
        if (d <= 0) return "WillbootJB/Configs/Salvas0Dias";
        if (d <= 51) return "WillbootJB/Configs/Salvas_1a51";
        int ini = 52 + ((d - 52) / 52) * 52;
        return "WillbootJB/Configs/Salvas_" + ini + "a" + (ini + 51);
    }

    private void saveConfigWithDays(String currentMac, String days, File tempFile) {
        try {
            String pasta = pastaPorDias(days);
            File baseDir = new File(Environment.getExternalStorageDirectory(), pasta);
            if (!baseDir.exists()) baseDir.mkdirs();
            runRoot("mkdir -p \"" + baseDir.getAbsolutePath() + "\"");

            String cleanMac = currentMac.replace(":", "");
            File destFile = new File(baseDir, days + "Dias_" + cleanMac + ".config");

            int seq = 1;
            while (destFile.exists()) {
                destFile = new File(baseDir, days + "Dias_" + cleanMac + "(" + seq + ").config");
                seq++;
            }

            // Pega o .config que o UniTV gerou na pasta Android, renomeia com os dias e move
            String origem = "/storage/emulated/0/Android/.config";
            String existe = runRootWithOutput("[ -f " + origem + " ] && echo SIM || echo NAO");
            if (existe == null || !existe.contains("SIM")) {
                addLog("ERRO: Android/.config não encontrado");
                return;
            }
            runRoot("mv " + origem + " \"" + destFile.getAbsolutePath() + "\"");
            runRoot("chmod 666 \"" + destFile.getAbsolutePath() + "\"");
            addLog("Movido: " + destFile.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Libera no Android todas as permissões que o UniTV pede (armazenamento, notificação etc.)
    // Assim a janela "Permitir?" não aparece depois do pm clear.
    private void grantAllPermissions() {
        String dump = runRootWithOutput("dumpsys package " + TARGET_PACKAGE);
        int count = 0;
        boolean inRequested = false;
        for (String raw : dump.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("requested permissions:")) { inRequested = true; continue; }
            if (inRequested) {
                if (!line.startsWith("android.permission.") && !line.contains(".permission.")) {
                    if (line.endsWith(":")) inRequested = false; // terminou a lista
                    continue;
                }
                String perm = line.split("[:,\\s]")[0];
                // pm grant só funciona nas permissões de "perigo"; nas outras dá erro e ignoramos
                runRoot("pm grant " + TARGET_PACKAGE + " " + perm + " 2>/dev/null");
                count++;
            }
        }
        // Garantias extras (alguns Android pedem por "app ops")
        runRoot("appops set " + TARGET_PACKAGE + " MANAGE_EXTERNAL_STORAGE allow 2>/dev/null");
        runRoot("appops set " + TARGET_PACKAGE + " SYSTEM_ALERT_WINDOW allow 2>/dev/null");
        runRoot("appops set " + TARGET_PACKAGE + " POST_NOTIFICATION allow 2>/dev/null");
        runRoot("appops set " + TARGET_PACKAGE + " REQUEST_INSTALL_PACKAGES allow 2>/dev/null");
        addLog("Permissões liberadas (" + count + ")");
    }

    // Por até 8s, procura botões tipo "Permitir", "OK", "Pular", "Concordo" e clica neles.
    // Se o leitor de tela não achar, e a janela de permissão do Android estiver na frente,
    // aperta OK no controle (Enter).
    private void skipStartupScreens(String fullMac) throws InterruptedException {
        updateBubbleInfo(fullMac, "Pulando telas de entrada...");
        int clicks = 0, empty = 0;
        long end = System.currentTimeMillis() + 15000;
        while (System.currentTimeMillis() < end && isRunning && clicks < 5) {
            Thread.sleep(700);
            AutoAccessibilityService acc = AutoAccessibilityService.getInstance();
            String clicked = acc != null ? acc.clickSkipButton() : null;
            if (clicked != null) {
                if (clicked.startsWith("KEY:")) {
                    runRoot("input keyevent 23"); // OK do controle no botão em foco
                    clicked = clicked.substring(4);
                }
                clicks++;
                addLog("Pulou: \"" + clicked + "\"");
                continue;
            }
            String focus = runRootWithOutput("dumpsys window windows | grep -i 'mCurrentFocus'");
            if (focus.contains("permissioncontroller") || focus.contains("packageinstaller")) {
                runRoot("input keyevent 22"); // seta direita (vai para "Permitir")
                runRoot("input keyevent 23"); // OK do controle
                clicks++;
                addLog("Pulou permissão (controle)");
                empty = 0;
                continue;
            }
            // v18: nada para pular 3 vezes seguidas -> vai logo para os cliques
            if (++empty >= 3) break;
        }
        if (clicks == 0) addLog("Nenhuma tela de entrada");
    }

    // Dá 2 cliques no meio da tela (1,5s entre eles) + OK do controle,
    // para passar as duas telas de entrada que o leitor não consegue pular.
    private void tapIntroScreens(String fullMac) throws InterruptedException {
        updateBubbleInfo(fullMac, "Clicando telas de entrada...");
        // v20: tamanho REAL da tela já virada (deitada/em pé). O "wm size"
        // dá sempre a tela em pé, e com a tela deitada o "meio" caía no botão OK.
        int w = 1920, h = 1080;
        try {
            WindowManager wmgr = (WindowManager) getSystemService(WINDOW_SERVICE);
            android.graphics.Point pt = new android.graphics.Point();
            wmgr.getDefaultDisplay().getRealSize(pt);
            if (pt.x > 0 && pt.y > 0) { w = pt.x; h = pt.y; }
        } catch (Exception ignored) {}
        int cx = w / 2, cy = h / 2;
        // v19: espera 1,5s, 1º clique, espera 3s, 2º clique.
        // Só o toque na tela: o OK do controle junto contava como outro clique seguido.
        for (int i = 1; i <= 2 && isRunning; i++) {
            Thread.sleep(i == 1 ? 3500 : 3000); // v31: 3,5s antes do 1º, 3s até o 2º (sem 3º clique)
            runRoot("input tap " + cx + " " + cy);
            addLog("Clique entrada " + i + "/2 (" + cx + "," + cy + ")");
        }
        Thread.sleep(1000);
    }

    private void stopAutomation() {
        isRunning = false;
        if (automationThread != null) automationThread.interrupt();
    }

    private void runRoot(String command) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", command});
            p.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String runRootWithOutput(String command) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", command});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            p.waitFor();
            return output.toString();
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopAutomation();
        if (bubbleView != null) windowManager.removeView(bubbleView);
    }

    // v25: detecta se está rodando em emulador
    private boolean isEmulator() {
        String fp = android.os.Build.FINGERPRINT + " " + android.os.Build.MODEL + " "
                + android.os.Build.HARDWARE + " " + android.os.Build.PRODUCT + " " + android.os.Build.MANUFACTURER;
        fp = fp.toLowerCase();
        return fp.contains("generic") || fp.contains("emulator") || fp.contains("sdk_gphone")
                || fp.contains("goldfish") || fp.contains("ranchu") || fp.contains("vbox")
                || fp.contains("nox") || fp.contains("ldplayer") || fp.contains("bluestacks")
                || fp.contains("memu") || fp.contains("genymotion") || fp.contains("android sdk");
    }
}
