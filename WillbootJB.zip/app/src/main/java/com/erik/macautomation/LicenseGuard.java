package com.erik.macautomation;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.X509EncodedKeySpec;

/**
 * Licença WillbootJB: chave de 11 caracteres presa a 1 aparelho.
 *
 * Proteções:
 *  - A resposta do servidor vem ASSINADA. O app só tem a chave PÚBLICA,
 *    então um servidor falso (trocando o endereço) não consegue dizer "OK".
 *  - Cada consulta usa um código aleatório (nonce): respostas antigas gravadas não servem.
 *  - Se o APK for recompilado/assinado por outra pessoa, ou estiver em modo depuração, o app fecha.
 */
public final class LicenseGuard {

    // ====== COLE AQUI OS DADOS DO PAINEL (botão "Mostrar") ======
    private static final String SERVER_URL = "https://tv-free-config-companion.lovable.app/api/public/license/verify";
    private static final String PUBLIC_KEY = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEPfCWjvf3TQuBmwxPUcRAeGGibqQLEhk6skCRxJLI4q3aqdzWxaV4VpeQKixLf5qU5F69467mDwdins9GVB/yvg==";
    // Impressão digital do SEU certificado de assinatura do APK.
    // Deixe vazio na 1ª vez: a tela de ativação mostra o valor certo para você copiar aqui.
    private static final String EXPECTED_CERT_SHA256 = "a8658560296981c8386689a4f990adcb3867870d5008f0c8b3e02c0908f872b7";
    // ============================================================

    private static final String PREFS = "wb_lic";
    private static volatile boolean sessionOk = false;

    public static final int OK = 0, INVALID = 1, BLOCKED = 2, OTHER_DEVICE = 3, NO_INTERNET = 4, TAMPERED = 5;

    private LicenseGuard() {}

    /** Usado pelos serviços: se a licença não foi conferida nesta abertura, eles não rodam. */
    public static boolean isSessionOk() { return sessionOk; }

    public static String savedKey(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("k", null);
    }

    private static void saveKey(Context c, String key) {
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (key == null) e.remove("k"); else e.putString("k", key);
        e.apply();
    }

    // ---------- Integridade do APK ----------

    public static String currentCertSha256(Context c) {
        try {
            PackageManager pm = c.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.getApkContentsSigners();
            } else {
                PackageInfo pi = pm.getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNATURES);
                sigs = pi.signatures;
            }
            return hex(MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray()));
        } catch (Exception e) {
            return "";
        }
    }

    /** true = APK original. */
    public static boolean integrityOk(Context c) {
        boolean debuggable = (c.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String esperado = EXPECTED_CERT_SHA256.replaceAll("[^0-9A-Fa-f]", "");
        if (esperado.isEmpty()) return true; // ainda não configurado
        if (debuggable) return false;
        String atual = currentCertSha256(c).replaceAll("[^0-9A-Fa-f]", "");
        return esperado.equalsIgnoreCase(atual);
    }

    /** Fecha o app de vez. */
    public static void breakApp() {
        sessionOk = false;
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

    // ---------- ID do aparelho ----------

    public static String deviceId(Context c) {
        String serial = rootGetprop("ro.serialno");
        if (serial.isEmpty()) serial = rootGetprop("ro.boot.serialno");
        String raw = serial + "|" + Build.BOARD + "|" + Build.BRAND + "|" + Build.DEVICE + "|"
                + Build.HARDWARE + "|" + Build.MANUFACTURER + "|" + Build.MODEL + "|" + Build.PRODUCT;
        try {
            return hex(MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            return "0000000000000000";
        }
    }

    private static String rootGetprop(String prop) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "getprop " + prop});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            p.waitFor();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"getprop", prop});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line = r.readLine();
                return line == null ? "" : line.trim();
            } catch (Exception ignored) {
                return "";
            }
        }
    }

    // ---------- Conferência no servidor (rode fora da thread principal) ----------

    public static int verify(Context c, String rawKey) {
        if (!integrityOk(c)) return TAMPERED;
        String key = rawKey == null ? "" : rawKey.toUpperCase().replaceAll("[^A-Z0-9]", "");
        String device = deviceId(c);
        String nonce = randomNonce();
        try {
            JSONObject req = new JSONObject();
            req.put("key", key);
            req.put("device_id", device);
            req.put("device_info", Build.MANUFACTURER + " " + Build.MODEL);
            req.put("nonce", nonce);

            HttpURLConnection con = (HttpURLConnection) new URL(SERVER_URL).openConnection();
            con.setRequestMethod("POST");
            con.setConnectTimeout(10000);
            con.setReadTimeout(10000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = con.getOutputStream()) {
                os.write(req.toString().getBytes(StandardCharsets.UTF_8));
            }
            if (con.getResponseCode() != 200) return NO_INTERNET;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) sb.append(l);
            }
            JSONObject res = new JSONObject(sb.toString());
            String payload = res.getString("payload");
            String sig = res.getString("sig");

            // Resposta sem assinatura válida = servidor falso -> quebra o app
            if (!signatureOk(payload, sig)) { breakApp(); return TAMPERED; }

            String[] parts = payload.split("\\|");
            if (parts.length != 5 || !parts[1].equals(key) || !parts[2].equals(device) || !parts[3].equals(nonce)) {
                breakApp();
                return TAMPERED;
            }
            switch (parts[0]) {
                case "OK":
                    saveKey(c, key);
                    sessionOk = true;
                    return OK;
                case "BLOCKED":
                    saveKey(c, null);
                    return BLOCKED;
                case "OTHER_DEVICE":
                    saveKey(c, null);
                    return OTHER_DEVICE;
                default:
                    saveKey(c, null);
                    return INVALID;
            }
        } catch (Exception e) {
            return NO_INTERNET;
        }
    }

    private static boolean signatureOk(String payload, String sigB64) {
        try {
            byte[] pub = Base64.decode(PUBLIC_KEY, Base64.DEFAULT);
            PublicKey pk = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(pub));
            java.security.Signature s = java.security.Signature.getInstance("SHA256withECDSA");
            s.initVerify(pk);
            s.update(payload.getBytes(StandardCharsets.UTF_8));
            return s.verify(Base64.decode(sigB64, Base64.DEFAULT));
        } catch (Exception e) {
            return false;
        }
    }

    private static String randomNonce() {
        byte[] b = new byte[16];
        new SecureRandom().nextBytes(b);
        return hex(b);
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    // ---------- Liberar a chave para outro aparelho ----------
    public static final String TELEGRAM_URL = "https://t.me/JBRAND96";

    /** Solta a chave do aparelho atual. O aparelho antigo perde o acesso. Rode fora da thread principal. */
    public static String release(Context c, String rawKey) {
        String key = rawKey == null ? "" : rawKey.toUpperCase().replaceAll("[^A-Z0-9]", "");
        try {
            JSONObject req = new JSONObject();
            req.put("key", key);
            HttpURLConnection con = (HttpURLConnection) new URL(SERVER_URL.replace("/verify", "/release")).openConnection();
            con.setRequestMethod("POST");
            con.setConnectTimeout(10000);
            con.setReadTimeout(10000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = con.getOutputStream()) {
                os.write(req.toString().getBytes(StandardCharsets.UTF_8));
            }
            if (con.getResponseCode() != 200) return "Sem internet. Conecte e tente de novo.";
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) sb.append(l);
            }
            String res = new JSONObject(sb.toString()).optString("result");
            switch (res) {
                case "RELEASED": saveKey(c, null); sessionOk = false; return "Chave liberada! Agora ative no outro aparelho.";
                case "ALREADY_FREE": return "Esta chave já está livre.";
                case "BLOCKED": return "Chave bloqueada";
                default: return "Chave inválida";
            }
        } catch (Exception e) {
            return "Sem internet. Conecte e tente de novo.";
        }
    }

    public static String message(int code) {
        switch (code) {
            case OK: return "Licença ativa";
            case INVALID: return "Chave inválida";
            case BLOCKED: return "Chave bloqueada";
            case OTHER_DEVICE: return "Esta chave já está ativada em outro aparelho";
            case NO_INTERNET: return "Sem internet. Conecte e tente de novo.";
            default: return "Aplicativo alterado";
        }
    }
}
