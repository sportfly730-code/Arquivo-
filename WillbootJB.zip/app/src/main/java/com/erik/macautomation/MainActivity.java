package com.erik.macautomation;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edtBaseMac, edtCoordX, edtCoordY, edtDelay;
    private Button btnStartAutomation;
    private static final String PREFS_NAME = "WillbootPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Licença: se a chave não foi conferida nesta abertura, volta para a tela de ativação
        if (!LicenseGuard.isSessionOk()) {
            startActivity(new Intent(this, LicenseActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        // Atualização: avisa se o painel tem versão nova
        UpdateChecker.check(this);

        edtBaseMac = findViewById(R.id.edtBaseMac);
        edtCoordX = findViewById(R.id.edtCoordX);
        edtCoordY = findViewById(R.id.edtCoordY);
        edtDelay = findViewById(R.id.edtDelay);
        btnStartAutomation = findViewById(R.id.btnStartAutomation);

        loadSavedInputs();
        requestRootPermission();

        btnStartAutomation.setOnClickListener(v -> {
            if (!canDrawOverlays()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                startActivity(intent);
                Toast.makeText(this, "Permita a sobreposição para o WillbootJB!", Toast.LENGTH_LONG).show();
                return;
            }

            if (AutoAccessibilityService.getInstance() == null) {
                Toast.makeText(this, "Ative o Serviço de Acessibilidade do WillbootJB nas configurações!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(intent);
                return;
            }

            if (!LicenseGuard.isSessionOk()) {
                startActivity(new Intent(this, LicenseActivity.class));
                finish();
                return;
            }

            saveInputs();

            Intent serviceIntent = new Intent(this, FloatingControlService.class);
            serviceIntent.putExtra("baseMac", edtBaseMac.getText().toString().trim());
            serviceIntent.putExtra("coordX", edtCoordX.getText().toString().trim());
            serviceIntent.putExtra("coordY", edtCoordY.getText().toString().trim());
            serviceIntent.putExtra("delay", edtDelay.getText().toString().trim());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }

            finish();
        });
    }

    private boolean canDrawOverlays() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private void requestRootPermission() {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                p.waitFor();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void saveInputs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("baseMac", edtBaseMac.getText().toString().trim());
        editor.putString("coordX", edtCoordX.getText().toString().trim());
        editor.putString("coordY", edtCoordY.getText().toString().trim());
        editor.putString("delay", edtDelay.getText().toString().trim());
        editor.apply();
    }

    private void loadSavedInputs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        edtBaseMac.setText(prefs.getString("baseMac", ""));
        edtCoordX.setText(prefs.getString("coordX", ""));
        edtCoordY.setText(prefs.getString("coordY", ""));
        edtDelay.setText(prefs.getString("delay", ""));
    }
}
