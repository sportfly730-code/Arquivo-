package com.erik.macautomation;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Primeira tela do app: pede a chave e confere no servidor antes de abrir o MainActivity. */
public class LicenseActivity extends Activity {

    private EditText input;
    private TextView status;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!LicenseGuard.integrityOk(this)) { LicenseGuard.breakApp(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(60, 60, 60, 60);
        root.setBackgroundColor(Color.parseColor("#0F172A"));

        TextView title = new TextView(this);
        title.setText("WillbootJB\nAtivação");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        input = new EditText(this);
        input.setHint("Chave de 11 caracteres");
        input.setHintTextColor(Color.GRAY);
        input.setTextColor(Color.WHITE);
        input.setGravity(Gravity.CENTER);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        input.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(11)});
        root.addView(input);

        button = new Button(this);
        button.setText("Ativar");
        button.setOnClickListener(v -> check(input.getText().toString()));
        root.addView(button);

        Button releaseBtn = new Button(this);
        releaseBtn.setText("Liberar código para outro aparelho");
        releaseBtn.setOnClickListener(v -> askRelease());
        root.addView(releaseBtn);

        Button contactBtn = new Button(this);
        contactBtn.setText("Contato com o suporte (Telegram)");
        contactBtn.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(LicenseGuard.TELEGRAM_URL))); }
            catch (Exception e) { Toast.makeText(this, "Telegram: @JBRAND96", Toast.LENGTH_LONG).show(); }
        });
        root.addView(contactBtn);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#FCA5A5"));
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 30, 0, 0);
        root.addView(status);

        // Ajuda para configurar EXPECTED_CERT_SHA256 (só aparece enquanto estiver vazio)
        final String cert = LicenseGuard.currentCertSha256(this);
        TextView certView = new TextView(this);
        certView.setTextColor(Color.parseColor("#94A3B8"));
        certView.setTextSize(10);
        certView.setPadding(0, 40, 0, 0);
        certView.setText("Certificado (toque para copiar):\n" + cert);
        certView.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("cert", cert));
            Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show();
        });
        if (isCertUnset()) root.addView(certView);

        setContentView(root);

        String saved = LicenseGuard.savedKey(this);
        if (saved != null) {
            input.setText(saved);
            check(saved);
        }
    }

    private void askRelease() {
        final String key = input.getText().toString().trim();
        if (key.length() != 11) { status.setText("Digite a chave de 11 caracteres primeiro"); return; }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Liberar código?")
                .setMessage("O aparelho onde a chave está ativada vai PERDER o acesso. Depois é só ativar no aparelho novo.")
                .setPositiveButton("Liberar", (d, w) -> {
                    status.setText("Liberando...");
                    new Thread(() -> {
                        String msg = LicenseGuard.release(this, key);
                        runOnUiThread(() -> status.setText(msg));
                    }).start();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private boolean isCertUnset() {
        try {
            java.lang.reflect.Field f = LicenseGuard.class.getDeclaredField("EXPECTED_CERT_SHA256");
            f.setAccessible(true);
            return ((String) f.get(null)).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private void check(String key) {
        button.setEnabled(false);
        status.setText("Conferindo...");
        new Thread(() -> {
            int r = LicenseGuard.verify(this, key);
            runOnUiThread(() -> {
                button.setEnabled(true);
                if (r == LicenseGuard.OK) {
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                } else if (r == LicenseGuard.TAMPERED) {
                    LicenseGuard.breakApp();
                } else {
                    status.setText(LicenseGuard.message(r));
                }
            });
        }).start();
    }
}
