package com.erik.macautomation;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AutoAccessibilityService extends AccessibilityService {
    private static volatile AutoAccessibilityService instance;
    private volatile String lastDetectedDays = "";

    private static final String TARGET_PACKAGE = "com.integration.unitvsiptv";

    // Preferencial: "...já está ativa por 3 dias" (o texto pode quebrar em várias linhas)
    private static final Pattern DAYS_ACTIVE_PATTERN = Pattern.compile(
            "ativ\\w*\\s+por\\s+(\\d{1,4})\\s*dias?",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    // Reserva: qualquer "N dia/dias/day/days", ignorando datas tipo 14-10-2026
    private static final Pattern DAYS_FALLBACK_PATTERN = Pattern.compile(
            "(?<![\\d\\-/])(\\d{1,4})\\s*(?:dias?|days?)\\b",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Só lê telas do UniTV (ignora a bolha e outros apps)
        if (event.getPackageName() == null
                || !TARGET_PACKAGE.contentEquals(event.getPackageName())) return;

        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode != null) {
            searchForActiveDays(rootNode);
            rootNode.recycle();
        }
    }

    private void searchForActiveDays(AccessibilityNodeInfo node) {
        if (node == null) return;

        CharSequence cs = node.getText();
        if (cs == null) cs = node.getContentDescription();
        if (cs != null) {
            String text = cs.toString();
            Matcher m = DAYS_ACTIVE_PATTERN.matcher(text);
            if (m.find()) {
                lastDetectedDays = m.group(1); // guarda só o número
            } else {
                Matcher f = DAYS_FALLBACK_PATTERN.matcher(text);
                if (f.find()) {
                    lastDetectedDays = f.group(1);
                }
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            searchForActiveDays(child);
            if (child != null) child.recycle();
        }
    }

    // Textos de botões que só servem para "passar" telas de entrada / permissão
    private static final String[] SKIP_WORDS = {
            "permitir", "allow", "while using the app", "durante o uso do app",
            "permitir sempre", "allow all the time", "ok", "pular", "skip",
            "concordo", "aceito", "aceitar", "agree", "accept", "i agree",
            "continuar", "continue", "próximo", "proximo", "next", "confirmar",
            "confirm", "experimente já", "experimente ja", "try now", "entendi", "got it", "fechar", "close", "começar", "start"
    };

    // Procura na tela da frente um botão de "passar" e clica. Retorna o texto clicado ou null.
    public String clickSkipButton() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        CharSequence pkg = root.getPackageName();
        String p = pkg == null ? "" : pkg.toString();
        // Só mexe no UniTV e nas janelas de permissão do Android (nunca na bolha)
        if (!(p.equals(TARGET_PACKAGE) || p.contains("permissioncontroller") || p.contains("packageinstaller"))) {
            root.recycle();
            return null;
        }
        String r = findAndClick(root);
        root.recycle();
        return r;
    }

    private String findAndClick(AccessibilityNodeInfo node) {
        if (node == null) return null;
        CharSequence cs = node.getText();
        if (cs == null) cs = node.getContentDescription();
        if (cs != null) {
            String t = cs.toString().trim().toLowerCase();
            for (String w : SKIP_WORDS) {
                if (t.equals(w)) {
                    AccessibilityNodeInfo c = node;
                    while (c != null && !c.isClickable()) c = c.getParent();
                    if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return cs.toString();
                    }
                    // Botão de TV que não aceita clique direto: avisa para apertar OK no controle
                    return "KEY:" + cs.toString();
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            String r = findAndClick(child);
            if (r != null) return r;
        }
        return null;
    }

    public String getLastDetectedDays() {
        return lastDetectedDays;
    }

    public void clearDetectedDays() {
        lastDetectedDays = "";
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }

    public static AutoAccessibilityService getInstance() {
        return instance;
    }
}
