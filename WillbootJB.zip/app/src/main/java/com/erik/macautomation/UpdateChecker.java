package com.erik.macautomation;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Pergunta ao painel se existe versão nova e oferece baixar e instalar. */
public class UpdateChecker {

    private static final String LATEST_URL = "https://tv-free-config-companion.lovable.app/api/public/app/latest";

    public static void check(Activity act) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(LATEST_URL).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                if (c.getResponseCode() != 200) return;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
                    String l; while ((l = r.readLine()) != null) sb.append(l);
                }
                JSONObject j = new JSONObject(sb.toString());
                int remote = j.optInt("version_code", 0);
                if (remote <= currentCode(act)) return;
                String name = j.optString("version_name");
                String notes = j.optString("notes");
                String url = j.optString("url");
                if (url.isEmpty()) return;
                act.runOnUiThread(() -> {
                    if (act.isFinishing()) return;
                    new AlertDialog.Builder(act)
                        .setTitle("Nova versão " + name + " disponível")
                        .setMessage((notes.isEmpty() ? "" : notes + "\n\n") + "Deseja atualizar agora?")
                        .setPositiveButton("Atualizar", (d, w) -> download(act, url))
                        .setNegativeButton("Depois", null)
                        .show();
                });
            } catch (Exception ignored) { }
        }).start();
    }

    private static long currentCode(Activity act) {
        try {
            PackageInfo p = act.getPackageManager().getPackageInfo(act.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
        } catch (Exception e) { return Long.MAX_VALUE; }
    }

    private static void download(Activity act, String url) {
        if (Build.VERSION.SDK_INT >= 26 && !act.getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(act, "Permita instalar apps do WillbootJB e toque em Atualizar de novo", Toast.LENGTH_LONG).show();
            act.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + act.getPackageName())));
            return;
        }
        ProgressDialog pd = new ProgressDialog(act);
        pd.setMessage("Baixando atualização…");
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setMax(100);
        pd.setCancelable(false);
        pd.show();
        new Thread(() -> {
            File out = new File(act.getCacheDir(), "update.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                int total = c.getContentLength();
                try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                    byte[] buf = new byte[16384];
                    long done = 0; int n;
                    while ((n = in.read(buf)) > 0) {
                        fo.write(buf, 0, n);
                        done += n;
                        if (total > 0) { int pct = (int) (done * 100 / total); act.runOnUiThread(() -> pd.setProgress(pct)); }
                    }
                }
                act.runOnUiThread(() -> { pd.dismiss(); install(act, out); });
            } catch (Exception e) {
                act.runOnUiThread(() -> { pd.dismiss(); Toast.makeText(act, "Falha ao baixar: " + e.getMessage(), Toast.LENGTH_LONG).show(); });
            }
        }).start();
    }

    private static void install(Activity act, File apk) {
        Uri uri = FileProvider.getUriForFile(act, act.getPackageName() + ".fileprovider", apk);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        act.startActivity(i);
    }
}
