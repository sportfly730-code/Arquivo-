
package com.ativadorjb.unitv;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.*;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    boolean telaHorizontal;

    int dp(float valor) {
        return Math.round(valor * getResources().getDisplayMetrics().density);
    }

    TextView status;
    Uri arquivo;
    File configLocal;
    final int PEDIR_PERMISSAO = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Ativador WillbootJB");
        }

        getWindow().setBackgroundDrawableResource(R.drawable.fundo_app);

        telaHorizontal = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;

        LinearLayout externo = new LinearLayout(this);
        externo.setOrientation(LinearLayout.VERTICAL);
        externo.setGravity(Gravity.CENTER);
        externo.setPadding(dp(24), dp(40), dp(24), dp(40));
        externo.setLayoutParams(new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);

        int larguraMax = dp(telaHorizontal ? 1040 : 650);
        int larguraTela = getResources().getDisplayMetrics().widthPixels;
        int larguraFinal = Math.max(dp(1), Math.min(larguraTela - dp(48), larguraMax));

        LinearLayout.LayoutParams paramsL = new LinearLayout.LayoutParams(
                larguraFinal,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        l.setLayoutParams(paramsL);

        l.setOrientation(telaHorizontal ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);

        LinearLayout botoes = new LinearLayout(this);
        botoes.setOrientation(LinearLayout.VERTICAL);
        LinearLayout detalhes = new LinearLayout(this);
        detalhes.setOrientation(LinearLayout.VERTICAL);
        if (telaHorizontal) {
            LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(0, -2, 1.1f);
            pb.setMargins(0, 0, dp(28), 0);
            botoes.setLayoutParams(pb);
            detalhes.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        } else {
            botoes.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            detalhes.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        }

        botoes.addView(btnComCirculo("LIMPEZA", v -> onDeleteAll()));
        botoes.addView(btnComCirculo("INSTALAR APPS", v -> mostrarMenuInstalacao()));
        botoes.addView(btnComCirculo("SELECIONAR CONFIG", v -> selecionarConfig()));
        botoes.addView(btnComCirculo("ACESSO ESPECIAL", v -> abrirAcessoEspecial()));
        botoes.addView(btnComCirculo("ABRIR UNITV", v -> abrirUniTV()));
        l.addView(botoes);
        l.addView(detalhes);

        TextView instrucoes = new TextView(this);

        instrucoes.setText(
                "PASSO A PASSO:\n\n" +
                "1 - Fa\u00e7a a limpeza.\n" +
                "2 - Instale o UniTV de sua prefer\u00eancia.\n" +
                "3 - Selecione a config para fazer a ativa\u00e7\u00e3o.\n" +
                "4 - D\u00ea a permiss\u00e3o especial do UniTV.\n" +
                "5 - Abra o UniTV."
        );

        instrucoes.setTextColor(0xFFFFFFFF);
        instrucoes.setPadding(dp(16), dp(16), dp(16), dp(16));
        instrucoes.setTypeface(null, Typeface.BOLD);
        instrucoes.setTextSize(telaHorizontal ? 18 : 16);
        instrucoes.setLineSpacing(dp(4), 1.15f);

        android.graphics.drawable.GradientDrawable gdCard =
                new android.graphics.drawable.GradientDrawable();

        gdCard.setColor(0x55555555);
        gdCard.setCornerRadius(15);
        gdCard.setStroke(1, 0xFFAAAAAA);

        instrucoes.setBackground(gdCard);
        detalhes.addView(instrucoes);

        status = new TextView(this);
        status.setText("Status: Aguardando a\u00e7\u00e3o");
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        status.setTextColor(0xFF00FF00);
        status.setTextSize(telaHorizontal ? 18 : 16);
        status.setTypeface(null, Typeface.BOLD);
        status.setGravity(Gravity.CENTER);

        android.graphics.drawable.GradientDrawable gdLog =
                new android.graphics.drawable.GradientDrawable();

        gdLog.setColor(0x44000000);
        gdLog.setCornerRadius(12);

        status.setBackground(gdLog);
        detalhes.addView(status);

        externo.addView(l);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);
        sv.addView(externo);

        setContentView(sv);

        pedirPermissao();
    }

    // ===== SELECIONAR CONFIG =====

    void selecionarConfig() {

        File pastaDownload = new File("/storage/emulated/0/Download");

        if (!pastaDownload.exists()) {
            pastaDownload = new File("/storage/emulated/0/Downloads");
        }

        if (!pastaDownload.exists()) {
            pastaDownload = new File("/storage/emulated/0");
        }

        abrirPastaTV(pastaDownload);
    }

    void abrirPastaTV(File pasta) {

        File[] arquivos = pasta.listFiles();

        if (arquivos == null) arquivos = new File[0];

        java.util.Arrays.sort(arquivos, (a, b) -> {
            if (a.isDirectory() && !b.isDirectory()) return -1;
            if (!a.isDirectory() && b.isDirectory()) return 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 30, 40, 30);
        layout.setBackgroundColor(0xFF444444);

        TextView titulo = new TextView(this);
        titulo.setText("Pasta: " + pasta.getAbsolutePath());
        titulo.setTextColor(0xFFFFFFFF);
        titulo.setTypeface(null, Typeface.BOLD);
        titulo.setPadding(0, 0, 0, 20);

        layout.addView(titulo);

        ListView lista = new ListView(this);

        ArrayList<String> nomes = new ArrayList<>();
        ArrayList<File> listaFiles = new ArrayList<>();

        if (pasta.getParentFile() != null) {
            nomes.add("VOLTAR (pasta anterior)");
            listaFiles.add(pasta.getParentFile());
        }

        for (File f : arquivos) {

            if (f.isDirectory()) {
                nomes.add("Pasta: " + f.getName());
                listaFiles.add(f);

            } else {

                if (f.getName().endsWith(".config") ||
                        f.getName().equals(".config") ||
                        !f.getName().contains(".")) {

                    nomes.add("Arquivo: " + f.getName());
                    listaFiles.add(f);
                }
            }
        }

        if (nomes.size() == 0 ||
                (nomes.size() == 1 && nomes.get(0).contains("VOLTAR"))) {

            nomes.add("Nenhum arquivo .config aqui");
            listaFiles.add(pasta);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                nomes
        ) {
            @Override
            public View getView(int position, View convertView,
                                android.view.ViewGroup parent) {

                TextView tv = (TextView) super.getView(
                        position, convertView, parent
                );

                tv.setTextColor(0xFFFFFFFF);
                tv.setTextSize(16);
                tv.setPadding(20, 25, 20, 25);

                return tv;
            }
        };

        lista.setAdapter(adapter);
        layout.addView(lista);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(layout)
                .setNegativeButton("FECHAR", null)
                .create();

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(
                    android.R.color.transparent
            );
        }

        lista.setOnItemClickListener((parent, view, pos, id) -> {

            if (nomes.get(pos).equals("Nenhum arquivo .config aqui")) {
                return;
            }

            File clicado = listaFiles.get(pos);

            if (clicado.isDirectory()) {

                dialog.dismiss();
                abrirPastaTV(clicado);

            } else {

                dialog.dismiss();

                try {

                    arquivo = Uri.fromFile(clicado);
                    configLocal = clicado;

                    onActivate();

                } catch (Exception e) {

                    status.setText("Status: Erro ao selecionar");
                }
            }
        });
    }

    // ===== LIMPEZA =====

    void onDeleteAll() {

        new AlertDialog.Builder(this)
                .setTitle("LIMPEZA")
                .setMessage("Apagar os dados e a configura\u00e7\u00e3o?")
                .setPositiveButton("CONFIRMAR", (d, w) -> apagarTudo())
                .setNegativeButton("CANCELAR", null)
                .show();
    }

    void apagarTudo() {

        try {

            new File("/storage/emulated/0/.config").delete();
            new File("/storage/emulated/0/Android/.config").delete();
            new File("/storage/emulated/0/.properties").delete();

            new File("/storage/emulated/0/Alarms/system_c/google.wav").delete();
            new File("/storage/emulated/0/Alarms/system_uf/google.wav").delete();

            if (configLocal != null) configLocal.delete();

        } catch (Exception e) {
        }

        arquivo = null;
        configLocal = null;

        getSharedPreferences("unitv_prefs", MODE_PRIVATE)
                .edit().clear().apply();

        getSharedPreferences("controle_configs", MODE_PRIVATE)
                .edit().clear().apply();

        status.setText("Status: Limpeza OK!");

        Toast.makeText(
                this,
                "Dados apagados",
                Toast.LENGTH_SHORT
        ).show();
    }

    // ===== BOT\u00d5ES =====

    View btnComCirculo(String t, View.OnClickListener c) {

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams cp =
                new LinearLayout.LayoutParams(-1, dp(telaHorizontal ? 56 : 60));

        cp.setMargins(0, dp(5), 0, dp(5));
        container.setLayoutParams(cp);

        View circulo = new View(this);

        android.graphics.drawable.GradientDrawable gdCirculo =
                new android.graphics.drawable.GradientDrawable();

        gdCirculo.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        gdCirculo.setColor(0xFFFFFFFF);
        gdCirculo.setStroke(2, 0xFFFF0000);

        circulo.setBackground(gdCirculo);
        circulo.setLayoutParams(new LinearLayout.LayoutParams(dp(12), dp(12)));
        circulo.setVisibility(View.INVISIBLE);

        Button b = new Button(this);

        b.setText(t);
        b.setTextColor(0xFFFFFFFF);
        b.setTypeface(null, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextSize(telaHorizontal ? 20 : 18);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMaxLines(2);
        b.setGravity(Gravity.CENTER);

        android.graphics.drawable.GradientDrawable gdNormal =
                new android.graphics.drawable.GradientDrawable();

        gdNormal.setColor(0xFF444444);
        gdNormal.setCornerRadius(dp(12));
        gdNormal.setStroke(1, 0xFF888888);

        b.setBackground(gdNormal);
        b.setFocusable(true);
        b.setFocusableInTouchMode(true);

        LinearLayout.LayoutParams bp =
                new LinearLayout.LayoutParams(0, -1);

        bp.weight = 1;
        b.setLayoutParams(bp);
        b.setOnClickListener(c);

        b.setOnFocusChangeListener((v, hasFocus) -> {

            android.graphics.drawable.GradientDrawable g =
                    new android.graphics.drawable.GradientDrawable();

            g.setCornerRadius(dp(12));

            if (hasFocus) {

                g.setColor(0xFF666666);
                g.setStroke(dp(3), 0xFFFFFFFF);

                b.setBackground(g);
                // Destaque sem ampliar: evita cortar o botao nas bordas.

                circulo.setVisibility(View.VISIBLE);

            } else {

                g.setColor(0xFF444444);
                g.setStroke(1, 0xFF888888);

                b.setBackground(g);
                b.setScaleX(1f);
                b.setScaleY(1f);

                circulo.setVisibility(View.INVISIBLE);
            }
        });

        container.addView(circulo);
        container.addView(b);

        return container;
    }

    // ===== MENU DE INSTALA\u00c7\u00c3O =====

    void mostrarMenuInstalacao() {

        String[] apps = {
                "unitv 4.21.0",
                "unitv 5.4.1",
                "UniTV Free 5.9.0"
        };

        String[] urls = {
                "https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/unitv-4.21.0.apk",
                "https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/unitv-5.4.1.apk",
                "https://raw.githubusercontent.com/sportfly730-code/Arquivo-/main/UniTV%20Free%205.9.0.apk"
        };

        String[] nomes = {
                "unitv-4.21.0.apk",
                "unitv-5.4.1.apk",
                "UniTV Free 5.9.0.apk"
        };

        LinearLayout layoutDialog = new LinearLayout(this);
        layoutDialog.setOrientation(LinearLayout.VERTICAL);
        layoutDialog.setPadding(40, 40, 40, 40);
        layoutDialog.setBackgroundColor(0xFF444444);

        TextView titulo = new TextView(this);
        titulo.setText("Escolha qual instalar");
        titulo.setTextColor(0xFFFFFFFF);
        titulo.setTypeface(null, Typeface.BOLD);

        layoutDialog.addView(titulo);

        TextView textoDownloadDialog = new TextView(this);
        textoDownloadDialog.setTextColor(0xFFFFFFFF);
        textoDownloadDialog.setVisibility(View.GONE);

        layoutDialog.addView(textoDownloadDialog);

        ProgressBar barraDialog = new ProgressBar(
                this,
                null,
                android.R.attr.progressBarStyleHorizontal
        );

        barraDialog.setVisibility(View.GONE);
        layoutDialog.addView(barraDialog);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(layoutDialog)
                .setNegativeButton("FECHAR", null)
                .create();

        dialog.setOnShowListener(d -> {

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawableResource(
                        android.R.color.transparent
                );
            }

            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                    .setTextColor(0xFF00FF00);
        });

        for (int i = 0; i < apps.length; i++) {

            int index = i;

            View botao = btnComCirculo(apps[i], v -> {

                textoDownloadDialog.setVisibility(View.VISIBLE);
                barraDialog.setVisibility(View.VISIBLE);

                baixarEInstalarDentroDialog(
                        urls[index],
                        nomes[index],
                        barraDialog,
                        textoDownloadDialog,
                        dialog
                );
            });

            layoutDialog.addView(botao);
        }

        dialog.show();
    }

    // ===== DOWNLOAD E INSTALA\u00c7\u00c3O =====

    void baixarEInstalarDentroDialog(
            String url,
            String nome,
            ProgressBar barra,
            TextView texto,
            AlertDialog dialogPai
    ) {

        try {

            DownloadManager.Request req =
                    new DownloadManager.Request(Uri.parse(url));

            req.setTitle(nome);

            req.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );

            req.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    nome
            );

            req.setMimeType("application/vnd.android.package-archive");

            DownloadManager dm =
                    (DownloadManager) getSystemService(DOWNLOAD_SERVICE);

            long id = dm.enqueue(req);

            new Thread(() -> {

                boolean downloading = true;

                while (downloading) {

                    DownloadManager.Query q =
                            new DownloadManager.Query();

                    q.setFilterById(id);

                    Cursor cursor = dm.query(q);

                    if (cursor.moveToFirst()) {

                        int st = cursor.getInt(
                                cursor.getColumnIndex(
                                        DownloadManager.COLUMN_STATUS
                                )
                        );

                        long baixado = cursor.getLong(
                                cursor.getColumnIndex(
                                        DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR
                                )
                        );

                        long total = cursor.getLong(
                                cursor.getColumnIndex(
                                        DownloadManager.COLUMN_TOTAL_SIZE_BYTES
                                )
                        );

                        if (total > 0) {

                            int prog = (int) ((baixado * 100) / total);

                            runOnUiThread(() -> {
                                barra.setProgress(prog);
                                texto.setText("Baixando " + nome + ": " + prog + "%");
                            });
                        }

                        if (st == DownloadManager.STATUS_SUCCESSFUL) {

                            downloading = false;

                            runOnUiThread(() -> {

                                dialogPai.dismiss();

                                File apk = new File(
                                        Environment.getExternalStoragePublicDirectory(
                                                Environment.DIRECTORY_DOWNLOADS
                                        ) + "/" + nome
                                );

                                Uri uri = FileProvider.getUriForFile(
                                        this,
                                        getPackageName() + ".provider",
                                        apk
                                );

                                Intent it = new Intent(Intent.ACTION_VIEW);

                                it.setDataAndType(
                                        uri,
                                        "application/vnd.android.package-archive"
                                );

                                it.addFlags(
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                        Intent.FLAG_ACTIVITY_NEW_TASK
                                );

                                startActivity(it);
                            });

                        } else if (st == DownloadManager.STATUS_FAILED) {

                            downloading = false;

                            runOnUiThread(() ->
                                    texto.setText("Erro ao baixar " + nome)
                            );
                        }
                    }

                    cursor.close();

                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                    }
                }

            }).start();

        } catch (Exception e) {

            status.setText("Erro: " + e.getMessage());
        }
    }

    // ===== PERMISS\u00d5ES =====

    void pedirPermissao() {

        if (Build.VERSION.SDK_INT >= 23) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE
                        },
                        PEDIR_PERMISSAO
                );
            }
        }
    }

    // ===== COPIAR CONFIG =====

    void copiarConfigParaPastas() {

        try {

            File f1 = new File("/storage/emulated/0/.config");
            File f2 = new File("/storage/emulated/0/Android/.config");

            f2.getParentFile().mkdirs();

            InputStream in = getContentResolver().openInputStream(arquivo);

            OutputStream out1 = new FileOutputStream(f1);
            OutputStream out2 = new FileOutputStream(f2);

            byte[] buf = new byte[4096];
            int len;

            while ((len = in.read(buf)) > 0) {

                out1.write(buf, 0, len);
                out2.write(buf, 0, len);
            }

            in.close();
            out1.close();
            out2.close();

        } catch (Exception e) {
        }
    }

    // ===== ATIVA\u00c7\u00c3O =====

    void onActivate() {

        if (arquivo == null) {

            Toast.makeText(
                    this,
                    "Nenhuma config! Clique em SELECIONAR CONFIG primeiro",
                    Toast.LENGTH_SHORT
            ).show();

            status.setText("Status: Nenhum arquivo");

            return;
        }

        copiarConfigParaPastas();

        status.setText("Ativa\u00e7\u00e3o OK!");

        Toast.makeText(
                this,
                "Ativa\u00e7\u00e3o OK!",
                Toast.LENGTH_LONG
        ).show();
    }

    // ===== ACESSO ESPECIAL (todos os arquivos do UniTV Free) =====

    static final String PACOTE_UNITV = "com.integration.unitvsiptv";

    void abrirUniTV() {
        try {
            Intent intent = getPackageManager().getLeanbackLaunchIntentForPackage(PACOTE_UNITV);
            if (intent == null) {
                intent = getPackageManager().getLaunchIntentForPackage(PACOTE_UNITV);
            }
            if (intent == null) {
                Toast.makeText(this,
                        "UniTV Free n\u00e3o est\u00e1 instalado ou n\u00e3o pode ser aberto. Instale primeiro.",
                        Toast.LENGTH_LONG).show();
                status.setText("Status: UniTV Free indispon\u00edvel");
                return;
            }
            startActivity(intent);
            status.setText("Status: UniTV Free aberto");
        } catch (Exception e) {
            status.setText("Status: N\u00e3o foi poss\u00edvel abrir o UniTV Free");
            Toast.makeText(this, "N\u00e3o foi poss\u00edvel abrir o UniTV Free", Toast.LENGTH_LONG).show();
        }
    }

    void abrirAcessoEspecial() {
        try {
            getPackageManager().getPackageInfo(PACOTE_UNITV, 0);
        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(this,
                    "UniTV Free n\u00e3o est\u00e1 instalado. Instale primeiro.",
                    Toast.LENGTH_LONG).show();
            status.setText("Status: UniTV Free n\u00e3o instalado");
            return;
        }

        Uri pacote = Uri.parse("package:" + PACOTE_UNITV);

        // Android 11 (API 30) ou superior: tela "Acesso a todos os arquivos"
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent it = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
                it.setData(pacote);
                startActivity(it);
                status.setText("Status: Ative \"Permitir acesso a todos os arquivos\"");
                return;
            } catch (Exception e) {
                // Alguns aparelhos/TV Box n\u00e3o t\u00eam essa tela: cai nas informa\u00e7\u00f5es do app
            }
        }

        try {
            Intent it = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            it.setData(pacote);
            startActivity(it);
            status.setText("Status: V\u00e1 em Permiss\u00f5es e libere Arquivos/Armazenamento");
        } catch (Exception e) {
            status.setText("Status: N\u00e3o foi poss\u00edvel abrir as configura\u00e7\u00f5es");
        }
    }
}
